import { z } from "zod";
import { router, publicProcedure, authedProcedure } from "../trpc";
import { users, sessions, cpfVerifications } from "../../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { hash, verify } from "argon2";
import { randomBytes } from "crypto";

// Generate CSPRNG salt
function generateSalt(length: number = 32) {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const bytes = randomBytes(length);
  return Array.from(bytes)
    .map((b) => chars[b % chars.length])
    .join("");
}

// Hash CPF with salt (SHA-256)
async function hashCpf(cpf: string, salt: string) {
  const crypto = await import("crypto");
  return crypto
    .createHash("sha256")
    .update(cpf + salt)
    .digest("hex");
}

export const authRouter = router({
  // ─────────────────────────────────────────────────────────────
  // PUBLIC PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // Register
  register: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string().min(6),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // Check if user exists
      const existing = await ctx.db.query.users.findFirst({
        where: eq(users.email, input.email),
      });

      if (existing) {
        throw new Error("Email já cadastrado");
      }

      // Hash password
      const passwordHash = await hash(input.password);

      // Create user
      const newUser = await ctx.db.insert(users).values({
        email: input.email,
        passwordHash,
        createdAt: new Date(),
        updatedAt: new Date(),
      }).returning();

      // Create session
      const sessionId = generateSalt(32);
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

      await ctx.db.insert(sessions).values({
        id: sessionId,
        userId: newUser[0].id,
        expiresAt,
        createdAt: new Date(),
      });

      return {
        user: {
          id: newUser[0].id,
          email: newUser[0].email,
        },
        sessionId,
      };
    }),

  // Login
  login: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // Find user
      const user = await ctx.db.query.users.findFirst({
        where: eq(users.email, input.email),
      });

      if (!user) {
        throw new Error("Email ou senha incorretos");
      }

      // Check if banned
      if (user.isBanned) {
        throw new Error("Conta banida: " + (user.banReason || "Violação dos termos"));
      }

      // Verify password
      const valid = await verify(user.passwordHash, input.password);
      if (!valid) {
        throw new Error("Email ou senha incorretos");
      }

      // Create session
      const sessionId = generateSalt(32);
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

      await ctx.db.insert(sessions).values({
        id: sessionId,
        userId: user.id,
        expiresAt,
        createdAt: new Date(),
      });

      // Update last login
      await ctx.db
        .update(users)
        .set({ lastLoginAt: new Date() })
        .where(eq(users.id, user.id));

      return {
        user: {
          id: user.id,
          email: user.email,
        },
        sessionId,
      };
    }),

  // Logout
  logout: authedProcedure.mutation(async ({ ctx }) => {
    const sessionId = ctx.req.headers["x-session-id"] as string;
    if (sessionId) {
      await ctx.db.delete(sessions).where(eq(sessions.id, sessionId));
    }
    return { success: true };
  }),

  // Get current user
  me: authedProcedure.query(async ({ ctx }) => {
    const user = await ctx.db.query.users.findFirst({
      where: eq(users.id, ctx.user.id),
      with: {
        cpfVerification: true,
        subscriptions: {
          where: eq(userSubscriptions.isActive, true),
          orderBy: desc(userSubscriptions.endDate),
          limit: 1,
        },
      },
    });

    return {
      id: user.id,
      email: user.email,
      isVerified: !!user.cpfVerification,
      isPremium: user.subscriptions?.length > 0,
      subscriptionEndsAt: user.subscriptions?.[0]?.endDate,
    };
  }),

  // ─────────────────────────────────────────────────────────────
  // CPF VERIFICATION (ECA Digital)
  // ─────────────────────────────────────────────────────────────

  // Verify CPF (via FonteData or direct)
  verifyCpf: authedProcedure
    .input(
      z.object({
        cpf: z.string().regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$|^\d{11}$/),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // Check if already verified
      const existing = await ctx.db.query.cpfVerifications.findFirst({
        where: eq(cpfVerifications.userId, ctx.user.id),
      });

      if (existing) {
        throw new Error("CPF já verificado");
      }

      // Clean CPF (remove formatting)
      const cleanCpf = input.cpf.replace(/\D/g, "");

      if (cleanCpf.length !== 11) {
        throw new Error("CPF inválido");
      }

      // In production: call FonteData API here
      // For now, we'll just hash and store
      const salt = generateSalt(32);
      const cpfHash = await hashCpf(cleanCpf, salt);

      // Store verification (CPF itself is discarded)
      await ctx.db.insert(cpfVerifications).values({
        userId: ctx.user.id,
        cpfHash,
        csprngSalt: salt,
        verifiedAt: new Date(),
        source: "fonte_data",
      });

      return { success: true, verified: true };
    }),

  // Check verification status
  checkVerification: authedProcedure.query(async ({ ctx }) => {
    const verification = await ctx.db.query.cpfVerifications.findFirst({
      where: eq(cpfVerifications.userId, ctx.user.id),
    });

    return {
      isVerified: !!verification,
      verifiedAt: verification?.verifiedAt,
    };
  }),
});
