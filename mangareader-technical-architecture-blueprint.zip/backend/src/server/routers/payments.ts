import { z } from "zod";
import { router, publicProcedure, authedProcedure } from "../trpc";
import { invoices, userSubscriptions, users } from "../../../drizzle/schema";
import { eq, and, gt } from "drizzle-orm";
import { randomBytes } from "crypto";

// Generate Monero subaddress (simplified - use real wallet lib in production)
function generateXmrSubaddress() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz123456789";
  const bytes = randomBytes(94);
  return "8" + Array.from(bytes).map((b) => chars[b % chars.length]).join("").slice(0, 94);
}

// XMR to BRL rate (fetch from API in production)
const XMR_BRL_RATE = 920;

export const paymentsRouter = router({
  // ─────────────────────────────────────────────────────────────
  // PUBLIC PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // Get current XMR rate
  getXmrRate: publicProcedure.query(() => {
    return {
      brl: XMR_BRL_RATE,
      updatedAt: new Date(),
    };
  }),

  // Get plan prices in XMR
  getPlanPrices: publicProcedure.query(() => {
    const plans = [
      { id: "monthly", brl: 10, days: 30 },
      { id: "quarterly", brl: 25, days: 90 },
      { id: "annual", brl: 80, days: 365 },
    ];

    return plans.map((p) => ({
      ...p,
      xmr: (p.brl / XMR_BRL_RATE).toFixed(8),
    }));
  }),

  // ─────────────────────────────────────────────────────────────
  // AUTHED PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // Create invoice for subscription
  createInvoice: authedProcedure
    .input(
      z.object({
        planType: z.enum(["monthly", "quarterly", "annual"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const prices: Record<string, number> = {
        monthly: 10,
        quarterly: 25,
        annual: 80,
      };

      const brlAmount = prices[input.planType];
      const xmrAmount = (brlAmount / XMR_BRL_RATE).toFixed(8);
      const xmrAddress = generateXmrSubaddress();

      // In production: create BTCPay invoice here
      const btcpayInvoiceId = `inv_${randomBytes(16).toString("hex")}`;

      const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

      const newInvoice = await ctx.db.insert(invoices).values({
        userId: ctx.user.id,
        btcpayInvoiceId,
        amountBrl: brlAmount.toString(),
        amountXmr: xmrAmount,
        xmrAddress,
        status: "pending",
        planType: input.planType,
        expiresAt,
        createdAt: new Date(),
        metadata: {
          source: "web",
          userAgent: ctx.req.headers["user-agent"],
        },
      }).returning();

      return {
        invoiceId: newInvoice[0].id,
        btcpayInvoiceId,
        xmrAddress,
        amountXmr,
        amountBrl: brlAmount,
        expiresAt,
        // In production: return BTCPay checkout URL
        checkoutUrl: `/invoice/${btcpayInvoiceId}`,
      };
    }),

  // Create donation invoice
  createDonationInvoice: authedProcedure
    .input(
      z.object({
        amountBrl: z.number().positive().optional(),
        amountXmr: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const brlAmount = input.amountBrl || 20;
      const xmrAmount = input.amountXmr || (brlAmount / XMR_BRL_RATE).toFixed(8);
      const xmrAddress = generateXmrSubaddress();

      const btcpayInvoiceId = `don_${randomBytes(16).toString("hex")}`;
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

      const newInvoice = await ctx.db.insert(invoices).values({
        userId: ctx.user.id,
        btcpayInvoiceId,
        amountBrl: brlAmount.toString(),
        amountXmr,
        xmrAddress,
        status: "pending",
        planType: "donation",
        expiresAt,
        createdAt: new Date(),
        metadata: {
          source: "donation",
          // No logging of IP for donations (privacy requirement)
        },
      }).returning();

      return {
        invoiceId: newInvoice[0].id,
        btcpayInvoiceId,
        xmrAddress,
        amountXmr,
        amountBrl: brlAmount,
        expiresAt,
      };
    }),

  // Check invoice status
  checkInvoice: authedProcedure
    .input(z.object({ invoiceId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const invoice = await ctx.db.query.invoices.findFirst({
        where: eq(invoices.id, input.invoiceId),
      });

      if (!invoice) {
        throw new Error("Fatura não encontrada");
      }

      // In production: check BTCPay webhook status
      return {
        status: invoice.status,
        paidAt: invoice.paidAt,
        amountXmr: invoice.amountXmr,
        amountBrl: invoice.amountBrl,
      };
    }),

  // Get user subscription status
  getSubscription: authedProcedure.query(async ({ ctx }) => {
    const subscription = await ctx.db.query.userSubscriptions.findFirst({
      where: and(
        eq(userSubscriptions.userId, ctx.user.id),
        eq(userSubscriptions.isActive, true),
        gt(userSubscriptions.endDate, new Date()),
      ),
      orderBy: (subscriptions, { desc }) => [desc(subscriptions.endDate)],
    });

    if (!subscription) {
      return {
        isActive: false,
        daysLeft: 0,
      };
    }

    const daysLeft = Math.ceil(
      (subscription.endDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24),
    );

    return {
      isActive: true,
      planType: subscription.planType,
      startDate: subscription.startDate,
      endDate: subscription.endDate,
      daysLeft: Math.max(0, daysLeft),
    };
  }),

  // ─────────────────────────────────────────────────────────────
  // WEBHOOK (BTCPay callback - would be a separate route)
  // ─────────────────────────────────────────────────────────────

  // This would be called by BTCPay webhook
  // processWebhook: publicProcedure...
});
