import { z } from "zod";
import { router, publicProcedure, adminProcedure } from "../trpc";
import { chapters, chapterPages } from "../../../drizzle/schema";
import { eq, desc, and } from "drizzle-orm";

export const chaptersRouter = router({
  // ─────────────────────────────────────────────────────────────
  // PUBLIC PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // Get chapters for a manga
  getByManga: publicProcedure
    .input(z.object({ mangaId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      return ctx.db.query.chapters.findMany({
        where: eq(chapters.mangaId, input.mangaId),
        orderBy: desc(chapters.number),
        with: {
          pages: {
            orderBy: chapterPages.pageNumber,
          },
        },
      });
    }),

  // Get single chapter with pages
  getChapter: publicProcedure
    .input(z.object({ chapterId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const chapter = await ctx.db.query.chapters.findFirst({
        where: eq(chapters.id, input.chapterId),
        with: {
          manga: true,
          pages: {
            orderBy: chapterPages.pageNumber,
          },
        },
      });

      if (!chapter) {
        throw new Error("Capítulo não encontrado");
      }

      return chapter;
    }),

  // Check if chapter is locked (early access)
  checkAccess: publicProcedure
    .input(z.object({ chapterId: z.string().uuid() }))
    .query(async ({ ctx, input }) => {
      const chapter = await ctx.db.query.chapters.findFirst({
        where: eq(chapters.id, input.chapterId),
      });

      if (!chapter) {
        throw new Error("Capítulo não encontrado");
      }

      const isPremium = ctx.user !== null; // Simplified - check subscription in production
      const isEarlyAccess = chapter.isPremiumOnly;
      const releasedAt = new Date(chapter.releasedAt).getTime();
      const now = Date.now();
      const hoursSinceRelease = (now - releasedAt) / (1000 * 60 * 60);
      const isLocked = isEarlyAccess && hoursSinceRelease < 72 && !isPremium;

      return {
        isLocked,
        isEarlyAccess,
        hoursUntilFree: isLocked ? Math.ceil(72 - hoursSinceRelease) : 0,
        canRead: !isLocked,
      };
    }),

  // ─────────────────────────────────────────────────────────────
  // ADMIN PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // Create chapter
  create: adminProcedure
    .input(
      z.object({
        mangaId: z.string().uuid(),
        number: z.number().int().positive(),
        title: z.string().min(1),
        pages: z.number().int().positive().default(20),
        releasedAt: z.string().datetime(),
        isPremiumOnly: z.boolean().default(false),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const newChapter = await ctx.db.insert(chapters).values({
        ...input,
        releasedAt: new Date(input.releasedAt),
        createdAt: new Date(),
        updatedAt: new Date(),
      }).returning();

      return newChapter[0];
    }),

  // Update chapter
  update: adminProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        data: z.object({
          number: z.number().int().positive().optional(),
          title: z.string().min(1).optional(),
          pages: z.number().int().positive().optional(),
          releasedAt: z.string().datetime().optional(),
          isPremiumOnly: z.boolean().optional(),
        }),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const updateData: any = {
        ...input.data,
        updatedAt: new Date(),
      };

      if (input.data.releasedAt) {
        updateData.releasedAt = new Date(input.data.releasedAt);
      }

      const updated = await ctx.db
        .update(chapters)
        .set(updateData)
        .where(eq(chapters.id, input.id))
        .returning();

      return updated[0];
    }),

  // Delete chapter
  delete: adminProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      await ctx.db.delete(chapters).where(eq(chapters.id, input.id));
      return { success: true };
    }),

  // Upload chapter pages (metadata - actual upload handled separately)
  uploadPages: adminProcedure
    .input(
      z.object({
        chapterId: z.string().uuid(),
        pages: z.array(
          z.object({
            pageNumber: z.number().int().positive(),
            imageUrl: z.string().url(),
            imageKey: z.string(),
            width: z.number().optional(),
            height: z.number().optional(),
          }),
        ),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      // Delete existing pages
      await ctx.db.delete(chapterPages).where(eq(chapterPages.chapterId, input.chapterId));

      // Insert new pages
      const pages = input.pages.map((p) => ({
        chapterId: input.chapterId,
        pageNumber: p.pageNumber,
        imageUrl: p.imageUrl,
        imageKey: p.imageKey,
        width: p.width,
        height: p.height,
        processedAt: new Date(),
        createdAt: new Date(),
      }));

      await ctx.db.insert(chapterPages).values(pages);

      // Update chapter page count
      await ctx.db
        .update(chapters)
        .set({
          pages: pages.length,
          updatedAt: new Date(),
        })
        .where(eq(chapters.id, input.chapterId));

      return { success: true, count: pages.length };
    }),
});
