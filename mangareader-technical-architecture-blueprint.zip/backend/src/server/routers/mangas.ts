import { z } from "zod";
import { router, publicProcedure, adminProcedure } from "../trpc";
import { mangas, chapters } from "../../../drizzle/schema";
import { eq, desc, asc, like, or, and } from "drizzle-orm";

export const mangasRouter = router({
  // ─────────────────────────────────────────────────────────────
  // PUBLIC PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // List all mangas with filters
  list: publicProcedure
    .input(
      z.object({
        type: z.enum(["Manga", "Manhwa", "Manhua", "Novel", "BR"]).optional(),
        status: z.enum(["Ativo", "Hiato", "Completo"]).optional(),
        genres: z.array(z.string()).optional(),
        search: z.string().optional(),
        sortBy: z.enum(["popular", "rating", "newest", "alpha"]).default("popular"),
        page: z.number().default(1),
        limit: z.number().default(20),
      }),
    )
    .query(async ({ ctx, input }) => {
      const { type, status, genres, search, sortBy, page, limit } = input;
      const offset = (page - 1) * limit;

      // Build where conditions
      const conditions = [];
      
      if (type) conditions.push(eq(mangas.type, type));
      if (status) conditions.push(eq(mangas.status, status));
      if (search) {
        conditions.push(
          or(
            like(mangas.title, `%${search}%`),
            like(mangas.author, `%${search}%`),
          ),
        );
      }

      // Build order
      let orderBy;
      switch (sortBy) {
        case "rating":
          orderBy = desc(mangas.rating);
          break;
        case "newest":
          orderBy = desc(mangas.createdAt);
          break;
        case "alpha":
          orderBy = asc(mangas.title);
          break;
        default:
          orderBy = desc(mangas.views);
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const [items, total] = await Promise.all([
        ctx.db.query.mangas.findMany({
          where,
          orderBy,
          limit,
          offset,
          with: {
            chapters: {
              limit: 1,
              orderBy: desc(chapters.number),
              columns: {
                number: true,
                releasedAt: true,
                isPremiumOnly: true,
              },
            },
          },
        }),
        ctx.db.select().from(mangas).where(where).then((rows) => rows.length),
      ]);

      return {
        items,
        total,
        page,
        totalPages: Math.ceil(total / limit),
      };
    }),

  // Get single manga by slug
  getBySlug: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ ctx, input }) => {
      const manga = await ctx.db.query.mangas.findFirst({
        where: eq(mangas.slug, input.slug),
        with: {
          chapters: {
            orderBy: desc(chapters.number),
            limit: 100,
          },
        },
      });

      if (!manga) {
        throw new Error("Mangá não encontrado");
      }

      // Increment views
      await ctx.db
        .update(mangas)
        .set({ views: manga.views + 1 })
        .where(eq(mangas.id, manga.id));

      return manga;
    }),

  // Get featured/spotlight mangas
  getFeatured: publicProcedure.query(async ({ ctx }) => {
    return ctx.db.query.mangas.findMany({
      where: eq(mangas.status, "Ativo"),
      orderBy: desc(mangas.rating),
      limit: 4,
    });
  }),

  // Get popular mangas
  getPopular: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ ctx, input }) => {
      return ctx.db.query.mangas.findMany({
        orderBy: desc(mangas.views),
        limit: input.limit,
      });
    }),

  // Get latest releases
  getLatest: publicProcedure
    .input(z.object({ limit: z.number().default(20) }))
    .query(async ({ ctx, input }) => {
      const latestChapters = await ctx.db.query.chapters.findMany({
        orderBy: desc(chapters.releasedAt),
        limit: input.limit,
        with: {
          manga: true,
        },
      });

      return latestChapters.map((ch) => ({
        ...ch,
        manga,
      }));
    }),

  // ─────────────────────────────────────────────────────────────
  // ADMIN PROCEDURES
  // ─────────────────────────────────────────────────────────────

  // Create new manga
  create: adminProcedure
    .input(
      z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        type: z.enum(["Manga", "Manhwa", "Manhua", "Novel", "BR"]),
        author: z.string().min(1),
        scanlation: z.string().optional(),
        status: z.enum(["Ativo", "Hiato", "Completo"]).default("Ativo"),
        genres: z.array(z.string()).default([]),
        rating: z.number().min(0).max(5).default(0),
        views: z.number().default(0),
        coverGradient: z.string().optional(),
        accentColor: z.string().optional(),
        synopsis: z.string().min(1),
        mature: z.boolean().default(false),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const newManga = await ctx.db.insert(mangas).values({
        ...input,
        createdAt: new Date(),
        updatedAt: new Date(),
      }).returning();

      return newManga[0];
    }),

  // Update manga
  update: adminProcedure
    .input(
      z.object({
        id: z.string().uuid(),
        data: z.object({
          title: z.string().min(1).optional(),
          slug: z.string().min(1).optional(),
          type: z.enum(["Manga", "Manhwa", "Manhua", "Novel", "BR"]).optional(),
          author: z.string().min(1).optional(),
          scanlation: z.string().optional(),
          status: z.enum(["Ativo", "Hiato", "Completo"]).optional(),
          genres: z.array(z.string()).optional(),
          rating: z.number().min(0).max(5).optional(),
          coverGradient: z.string().optional(),
          accentColor: z.string().optional(),
          synopsis: z.string().min(1).optional(),
          mature: z.boolean().optional(),
        }),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const updated = await ctx.db
        .update(mangas)
        .set({
          ...input.data,
          updatedAt: new Date(),
        })
        .where(eq(mangas.id, input.id))
        .returning();

      return updated[0];
    }),

  // Delete manga
  delete: adminProcedure
    .input(z.object({ id: z.string().uuid() }))
    .mutation(async ({ ctx, input }) => {
      await ctx.db.delete(mangas).where(eq(mangas.id, input.id));
      return { success: true };
    }),
});
