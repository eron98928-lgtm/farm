import { router } from "./trpc";
import { mangasRouter } from "./routers/mangas";
import { chaptersRouter } from "./routers/chapters";
import { authRouter } from "./routers/auth";
import { paymentsRouter } from "./routers/payments";

export const appRouter = router({
  mangas: mangasRouter,
  chapters: chaptersRouter,
  auth: authRouter,
  payments: paymentsRouter,
});

export type AppRouter = typeof appRouter;
