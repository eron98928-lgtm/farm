import type { inferAsyncReturnType } from "@trpc/server";
import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { db } from "../db";
import { sessions, users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export async function createContext({ req, res }: CreateExpressContextOptions) {
  // Get session from cookie/header
  const sessionId = req.headers["x-session-id"] as string | undefined;
  
  let user: {
    id: string;
    email: string;
    isAdmin: boolean;
  } | null = null;

  if (sessionId) {
    try {
      // Verify session
      const session = await db.query.sessions.findFirst({
        where: eq(sessions.id, sessionId),
        with: {
          user: {
            columns: {
              id: true,
              email: true,
            },
          },
        },
      });

      if (session && session.expiresAt > new Date()) {
        // Check if user is banned
        const userRecord = await db.query.users.findFirst({
          where: eq(users.id, session.userId),
          columns: {
            id: true,
            email: true,
            isBanned: true,
          },
        });

        if (userRecord && !userRecord.isBanned) {
          user = {
            id: userRecord.id,
            email: userRecord.email,
            isAdmin: userRecord.email === "eron98928@gmail.com", // Simple admin check
          };
        }
      }
    } catch (error) {
      console.error("Session validation error:", error);
    }
  }

  return {
    req,
    res,
    db,
    user,
    ip: req.ip || req.socket.remoteAddress,
  };
}

export type Context = inferAsyncReturnType<typeof createContext>;
