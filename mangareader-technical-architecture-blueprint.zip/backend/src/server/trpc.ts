import { initTRPC, TRPCError } from "@trpc/server";
import type { Context } from "./context";

const t = initTRPC.context<Context>().create();

// Base middlewares
const isAuthed = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Você precisa estar logado",
    });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

const isAdmin = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user || !ctx.user.isAdmin) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Acesso restrito a administradores",
    });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

const rateLimiter = t.middleware(async ({ ctx, next, path }) => {
  // Simple rate limiting - in production use Redis
  const ip = ctx.ip || "unknown";
  const key = `rate:${ip}:${path}`;
  
  // Check if rate limited (simplified - use Redis in production)
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 100;
  
  // Store in memory for demo (use Redis in production)
  const rateData = (ctx as any).rateLimitStore || new Map();
  const record = rateData.get(key) || { count: 0, resetAt: now + windowMs };
  
  if (now > record.resetAt) {
    record.count = 1;
    record.resetAt = now + windowMs;
  } else {
    record.count++;
  }
  
  if (record.count > maxRequests) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Muitas requisições. Tente novamente em alguns segundos.",
    });
  }
  
  rateData.set(key, record);
  (ctx as any).rateLimitStore = rateData;
  
  return next();
});

// Base router and procedures
export const router = t.router;
export const publicProcedure = t.procedure.use(rateLimiter);
export const authedProcedure = t.procedure.use(rateLimiter).use(isAuthed);
export const adminProcedure = t.procedure.use(rateLimiter).use(isAdmin);
