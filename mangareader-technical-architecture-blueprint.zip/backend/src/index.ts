import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { expressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "./server";
import { createContext } from "./server/context";
import { db } from "./db";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// ─────────────────────────────────────────────────────────────
// SECURITY MIDDLEWARE
// ─────────────────────────────────────────────────────────────

// Helmet for security headers
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
      },
    },
    hsts: {
      maxAge: 63072000,
      includeSubDomains: true,
      preload: true,
    },
  }),
);

// CORS
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true,
  }),
);

// Rate limiting
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: "Muitas requisições. Tente novamente em alguns segundos.",
  standardHeaders: true,
  legacyHeaders: false,
});

app.use("/trpc", limiter);

// Body parser
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// ─────────────────────────────────────────────────────────────
// TRPC ENDPOINT
// ─────────────────────────────────────────────────────────────

app.use(
  "/trpc",
  expressMiddleware(appRouter, {
    createContext,
    onError({ path, error, type, req }) {
      console.error(`tRPC Error on ${path}:`, error.message);
      
      // Log security events for certain errors
      if (error.code === "UNAUTHORIZED" || error.code === "FORBIDDEN") {
        console.log(`Security event: ${error.code} on ${path} from ${req?.ip}`);
      }
    },
  }),
);

// ─────────────────────────────────────────────────────────────
// HEALTH CHECK
// ─────────────────────────────────────────────────────────────

app.get("/health", async (req, res) => {
  try {
    await db.select().from(db.query.users.findFirst());
    res.json({ status: "healthy", database: "connected" });
  } catch (error) {
    res.status(500).json({ status: "unhealthy", error: "Database connection failed" });
  }
});

// ─────────────────────────────────────────────────────────────
// START SERVER
// ─────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`🚀 MangaReader API running on port ${PORT}`);
  console.log(`📡 tRPC endpoint: http://localhost:${PORT}/trpc`);
  console.log(`❤️  Health check: http://localhost:${PORT}/health`);
});
