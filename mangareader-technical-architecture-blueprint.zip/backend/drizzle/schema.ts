import {
  pgTable,
  text,
  timestamp,
  integer,
  decimal,
  boolean,
  jsonb,
  uuid,
  index,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ─────────────────────────────────────────────────────────────
// USERS & AUTH (Lucia Auth)
// ─────────────────────────────────────────────────────────────

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    lastLoginAt: timestamp("last_login_at"),
    isBanned: boolean("is_banned").default(false).notNull(),
    banReason: text("ban_reason"),
  },
  (table) => [index("users_email_idx").on(table.email)],
);

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─────────────────────────────────────────────────────────────
// CPF VERIFICATION (ECA Digital - Lei 15.211/2025)
// ─────────────────────────────────────────────────────────────

export const cpfVerifications = pgTable("cpf_verifications", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  cpfHash: text("cpf_hash").notNull().unique(), // SHA-256(CPF + CSPRNG_Salt)
  csprngSalt: text("csprng_salt").notNull(), // 32+ chars unique salt
  verifiedAt: timestamp("verified_at").defaultNow(),
  source: text("source").default("fonte_data"), // API partner
});

// ─────────────────────────────────────────────────────────────
// MANGAS & CHAPTERS
// ─────────────────────────────────────────────────────────────

export const mangas = pgTable(
  "mangas",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    slug: text("slug").notNull().unique(),
    type: text("type", {
      enum: ["Manga", "Manhwa", "Manhua", "Novel", "BR"],
    }).notNull(),
    author: text("author").notNull(),
    scanlation: text("scanlation"),
    status: text("status", {
      enum: ["Ativo", "Hiato", "Completo"],
    })
      .default("Ativo")
      .notNull(),
    genres: jsonb("genres").$type<string[]>().default([]),
    rating: decimal("rating", { precision: 2, scale: 1 }).default("0.0"),
    views: integer("views").default(0).notNull(),
    coverGradient: text("cover_gradient"),
    accentColor: text("accent_color"),
    synopsis: text("synopsis").notNull(),
    mature: boolean("mature").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("mangas_slug_idx").on(table.slug),
    index("mangas_type_idx").on(table.type),
    index("mangas_status_idx").on(table.status),
  ],
);

export const chapters = pgTable(
  "chapters",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    mangaId: uuid("manga_id")
      .notNull()
      .references(() => mangas.id, { onDelete: "cascade" }),
    number: integer("number").notNull(),
    title: text("title").notNull(),
    pages: integer("pages").notNull().default(0),
    releasedAt: timestamp("released_at").notNull(),
    isPremiumOnly: boolean("is_premium_only").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("chapters_manga_idx").on(table.mangaId),
    index("chapters_number_idx").on(table.number),
    index("chapters_released_idx").on(table.releasedAt),
  ],
);

export const chapterPages = pgTable(
  "chapter_pages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    chapterId: uuid("chapter_id")
      .notNull()
      .references(() => chapters.id, { onDelete: "cascade" }),
    pageNumber: integer("page_number").notNull(),
    imageUrl: text("image_url").notNull(),
    imageKey: text("image_key").notNull(), // S3/R2 key
    width: integer("width"),
    height: integer("height"),
    processedAt: timestamp("processed_at"), // sharp processing timestamp
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("pages_chapter_idx").on(table.chapterId),
    index("pages_number_idx").on(table.pageNumber),
  ],
);

// ─────────────────────────────────────────────────────────────
// USER ACTIVITY
// ─────────────────────────────────────────────────────────────

export const userHistory = pgTable(
  "user_history",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    mangaId: uuid("manga_id")
      .notNull()
      .references(() => mangas.id, { onDelete: "cascade" }),
    chapterId: uuid("chapter_id").references(() => chapters.id, {
      onDelete: "set null",
    }),
    currentPage: integer("current_page").default(1),
    lastReadAt: timestamp("last_read_at").defaultNow().notNull(),
  },
  (table) => [
    index("history_user_idx").on(table.userId),
    index("history_manga_idx").on(table.mangaId),
    index("history_last_read_idx").on(table.lastReadAt),
  ],
);

export const userFavorites = pgTable(
  "user_favorites",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    mangaId: uuid("manga_id")
      .notNull()
      .references(() => mangas.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("favorites_user_idx").on(table.userId),
    index("favorites_manga_idx").on(table.mangaId),
    index("favorites_unique").on(table.userId, table.mangaId).unique(),
  ],
);

// ─────────────────────────────────────────────────────────────
// SUBSCRIPTIONS & PAYMENTS
// ─────────────────────────────────────────────────────────────

export const userSubscriptions = pgTable(
  "user_subscriptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    planType: text("plan_type", {
      enum: ["monthly", "quarterly", "annual"],
    }).notNull(),
    startDate: timestamp("start_date").notNull(),
    endDate: timestamp("end_date").notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    autoRenew: boolean("auto_renew").default(false).notNull(), // Always false per spec
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [
    index("subscriptions_user_idx").on(table.userId),
    index("subscriptions_end_date_idx").on(table.endDate),
    index("subscriptions_active_idx").on(table.isActive),
  ],
);

export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    btcpayInvoiceId: text("btcpay_invoice_id").notNull().unique(),
    amountBrl: decimal("amount_brl", { precision: 10, scale: 2 }).notNull(),
    amountXmr: decimal("amount_xmr", { precision: 12, scale: 8 }).notNull(),
    xmrAddress: text("xmr_address").notNull(), // Rotated subaddress
    status: text("status", {
      enum: ["pending", "paid", "expired", "invalid"],
    })
      .default("pending")
      .notNull(),
    planType: text("plan_type", {
      enum: ["monthly", "quarterly", "annual", "donation"],
    }),
    paidAt: timestamp("paid_at"),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    metadata: jsonb("metadata"), // Additional BTCPay data
  },
  (table) => [
    index("invoices_user_idx").on(table.userId),
    index("invoices_btcpay_idx").on(table.btcpayInvoiceId),
    index("invoices_status_idx").on(table.status),
  ],
);

// ─────────────────────────────────────────────────────────────
// SECURITY & AUDIT
// ─────────────────────────────────────────────────────────────

export const userRiskScores = pgTable(
  "user_risk_scores",
  {
    userId: uuid("user_id")
      .primaryKey()
      .references(() => users.id, { onDelete: "cascade" }),
    score: integer("score").default(0).notNull(), // 0-100
    reasons: jsonb("reasons").$type<string[]>().default([]),
    lastCalculatedAt: timestamp("last_calculated_at").defaultNow(),
    isBlocked: boolean("is_blocked").default(false).notNull(),
  },
  (table) => [index("risk_scores_idx").on(table.score)],
);

export const securityEvents = pgTable(
  "security_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id),
    eventType: text("event_type").notNull(),
    ipAddress: text("ip_address"), // Hashed for privacy
    userAgent: text("user_agent"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("security_events_user_idx").on(table.userId),
    index("security_events_type_idx").on(table.eventType),
    index("security_events_created_idx").on(table.createdAt),
  ],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorUserId: uuid("actor_user_id").references(() => users.id),
    action: text("action").notNull(),
    resource: text("resource").notNull(), // e.g., "manga", "chapter", "user"
    resourceId: uuid("resource_id"),
    changes: jsonb("changes"), // Before/after diff
    ipAddress: text("ip_address"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => [
    index("audit_logs_actor_idx").on(table.actorUserId),
    index("audit_logs_resource_idx").on(table.resource, table.resourceId),
    index("audit_logs_created_idx").on(table.createdAt),
  ],
);

// ─────────────────────────────────────────────────────────────
// EMAIL & NOTIFICATIONS
// ─────────────────────────────────────────────────────────────

export const emailLogs = pgTable(
  "email_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id),
    to: text("to").notNull(),
    subject: text("subject").notNull(),
    template: text("template").notNull(),
    status: text("status", {
      enum: ["sent", "delivered", "bounced", "failed"],
    }).notNull(),
    error: text("error"),
    sentAt: timestamp("sent_at").defaultNow().notNull(),
  },
  (table) => [
    index("email_logs_user_idx").on(table.userId),
    index("email_logs_status_idx").on(table.status),
  ],
);

export const userNotificationPreferences = pgTable(
  "user_notification_preferences",
  {
    userId: uuid("user_id")
      .primaryKey()
      .references(() => users.id, { onDelete: "cascade" }),
    emailNewChapters: boolean("email_new_chapters").default(true).notNull(),
    emailPromotions: boolean("email_promotions").default(false).notNull(),
    pushNewChapters: boolean("push_new_chapters").default(true).notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [index("notif_prefs_user_idx").on(table.userId)],
);

// ─────────────────────────────────────────────────────────────
// RELATIONS
// ─────────────────────────────────────────────────────────────

export const usersRelations = relations(users, ({ one, many }) => ({
  sessions: many(sessions),
  cpfVerification: one(cpfVerifications),
  riskScore: one(userRiskScores),
  notificationPrefs: one(userNotificationPreferences),
  subscriptions: many(userSubscriptions),
  invoices: many(invoices),
  history: many(userHistory),
  favorites: many(userFavorites),
  securityEvents: many(securityEvents),
  auditLogs: many(auditLogs),
  emailLogs: many(emailLogs),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

export const cpfVerificationsRelations = relations(cpfVerifications, ({ one }) => ({
  user: one(users, {
    fields: [cpfVerifications.userId],
    references: [users.id],
  }),
}));

export const mangasRelations = relations(mangas, ({ many }) => ({
  chapters: many(chapters),
  userHistory: many(userHistory),
  userFavorites: many(userFavorites),
}));

export const chaptersRelations = relations(chapters, ({ one, many }) => ({
  manga: one(mangas, {
    fields: [chapters.mangaId],
    references: [mangas.id],
  }),
  pages: many(chapterPages),
  userHistory: many(userHistory),
}));

export const chapterPagesRelations = relations(chapterPages, ({ one }) => ({
  chapter: one(chapters, {
    fields: [chapterPages.chapterId],
    references: [chapters.id],
  }),
}));

export const userSubscriptionsRelations = relations(userSubscriptions, ({ one }) => ({
  user: one(users, {
    fields: [userSubscriptions.userId],
    references: [users.id],
  }),
}));

export const invoicesRelations = relations(invoices, ({ one }) => ({
  user: one(users, {
    fields: [invoices.userId],
    references: [users.id],
  }),
}));

export const userHistoryRelations = relations(userHistory, ({ one }) => ({
  user: one(users, {
    fields: [userHistory.userId],
    references: [users.id],
  }),
  manga: one(mangas, {
    fields: [userHistory.mangaId],
    references: [mangas.id],
  }),
  chapter: one(chapters, {
    fields: [userHistory.chapterId],
    references: [chapters.id],
  }),
}));

export const userFavoritesRelations = relations(userFavorites, ({ one }) => ({
  user: one(users, {
    fields: [userFavorites.userId],
    references: [users.id],
  }),
  manga: one(mangas, {
    fields: [userFavorites.mangaId],
    references: [mangas.id],
  }),
}));
