# MangaReader Backend

Backend API para a plataforma MangaReader, construído com **Node.js + Express + tRPC + PostgreSQL + Drizzle ORM**.

## 🏗️ Arquitetura

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   Frontend  │────▶│  API (tRPC)  │────▶│ PostgreSQL  │
│   (React)   │◀────│  (Express)   │◀────│  (Drizzle)  │
└─────────────┘     └──────────────┘     └─────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   BTCPay     │
                    │   (XMR)      │
                    └──────────────┘
```

## 🚀 Quick Start

### 1. Subir infraestrutura com Docker

```bash
# Copiar variáveis de ambiente
cp .env.example .env

# Editar .env com suas credenciais

# Subir todos os serviços
docker-compose up -d
```

### 2. Instalar dependências do backend

```bash
cd backend
npm install
```

### 3. Rodar migrations do banco

```bash
npm run db:push
```

### 4. Iniciar servidor de desenvolvimento

```bash
npm run dev
```

API estará disponível em `http://localhost:3000`

## 📡 Endpoints tRPC

### Auth
- `auth.register` - Criar conta
- `auth.login` - Login
- `auth.logout` - Logout
- `auth.me` - Dados do usuário atual
- `auth.verifyCpf` - Verificar CPF (ECA Digital)

### Mangás
- `mangas.list` - Listar mangás com filtros
- `mangas.getBySlug` - Obter mangá por slug
- `mangas.getFeatured` - Mangás em destaque
- `mangas.getPopular` - Mangás populares
- `mangas.getLatest` - Lançamentos recentes

### Capítulos
- `chapters.getByManga` - Capítulos de um mangá
- `chapters.getChapter` - Capítulo com páginas
- `chapters.checkAccess` - Verificar se pode ler (early access)

### Pagamentos
- `payments.getXmrRate` - Cotação XMR/BRL
- `payments.getPlanPrices` - Preços dos planos
- `payments.createInvoice` - Criar fatura de assinatura
- `payments.createDonationInvoice` - Criar fatura de doação
- `payments.getSubscription` - Status da assinatura

## 🔐 Segurança

### Headers (Helmet)
- Content-Security-Policy restritivo
- Strict-Transport-Security (HSTS)
- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY

### Rate Limiting
- 100 requisições/minuto por IP
- Aplicado em todos os endpoints tRPC

### Senhas
- Hash com Argon2id
- Salt automático

### CPF
- Nunca armazenado em texto claro
- SHA-256(CPF + CSPRNG_Salt)
- Salt único por usuário (32+ chars)

### Sessões
- Tokens aleatórios de 32 bytes
- Expiração em 30 dias
- Invalidadas no logout

## 📊 Schema do Banco

### Tabelas Principais
- `users` - Usuários e auth
- `cpf_verifications` - Verificação CPF (hash apenas)
- `mangas` - Catálogo de obras
- `chapters` - Capítulos
- `chapter_pages` - Páginas dos capítulos
- `user_history` - Histórico de leitura
- `user_favorites` - Favoritos
- `user_subscriptions` - Assinaturas ativas
- `invoices` - Faturas BTCPay
- `security_events` - Eventos de segurança
- `audit_logs` - Logs de auditoria

## 💰 Pagamentos (Monero)

### Fluxo de Assinatura
1. Usuário escolhe plano (Mensal R$10, Trimestral R$25, Anual R$80)
2. API cria fatura no BTCPay Server
3. Gera sub-endereço XMR único para esta fatura
4. Usuário paga para o endereço
5. BTCPay webhook confirma pagamento
6. API ativa assinatura e soma dias ao saldo

### Doações
- Mesmo fluxo, sem ativar assinatura
- Sem logs de IP (privacidade)
- Endereço rotacionado por doação

## 🛠️ Comandos Úteis

```bash
# Desenvolvimento
npm run dev          # Iniciar com hot-reload

# Build
npm run build        # Compilar TypeScript
npm start            # Rodar em produção

# Database
npm run db:generate  # Gerar migrations
npm run db:migrate   # Aplicar migrations
npm run db:push      # Push direto (dev)
npm run db:studio    # Drizzle Studio (GUI)
```

## 📦 Deploy em Produção

### VPS (Islândia/Suíça)

1. **Configurar VPS** com Docker
2. **Clonar repositório**
3. **Configurar .env** com secrets de produção
4. **Subir serviços**: `docker-compose up -d`
5. **Configurar reverse proxy** (Nginx/Caddy)
6. **Setup SSL** (Let's Encrypt)
7. **Configurar BTCPay** com nó Monero real

### Variáveis de Produção Obrigatórias
```bash
NODE_ENV=production
DATABASE_URL=postgresql://user:pass@host:5432/db
JWT_SECRET=<32+ chars random>
SESSION_SECRET=<32+ chars random>
BTCPAY_API_KEY=<from BTCPay>
FONTE_DATA_API_KEY=<from FonteData>
RESEND_API_KEY=<from Resend>
```

## 📝 Notas

- **Admin**: Email `eron98928@gmail.com` tem acesso ao painel admin
- **Early Access**: Capítulos lançados há <72h são premium-only
- **Renovação**: Sempre manual, dias são acumulativos
- **Privacidade**: Doações não loggam IP

## 📄 Licença

Proprietário - Todos os direitos reservados
