import { useMemo, useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import Login from "./components/Login";
import AgeGate from "./components/AgeGate";
import Header from "./components/Header";
import Reader from "./components/Reader";
import InvoiceModal from "./components/InvoiceModal";
import Toast from "./components/Toast";
import Footer from "./components/Footer";
import HomePage from "./pages/HomePage";
import CatalogPage from "./pages/CatalogPage";
import LatestPage from "./pages/LatestPage";
import PlansPage from "./pages/PlansPage";
import DonatePage from "./pages/DonatePage";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import { MANGAS, type Manga } from "./data/mangas";
import { type Plan, xmrFromBrl } from "./data/plans";

type Invoice = {
  title: string;
  brl: number;
  xmr: string;
  durationDays?: number;
  kind: "subscription" | "donation";
};

type Stage = "login" | "age" | "app";

function AppContent() {
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(() => localStorage.getItem("admin_auth") === "true");
  const [isPremium, setIsPremium] = useState(false);
  const [daysLeft, setDaysLeft] = useState(0);
  const [reading, setReading] = useState<Manga | null>(null);
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    setIsAdmin(localStorage.getItem("admin_auth") === "true");
  }, []);

  const rows = useMemo(() => {
    const popular = [...MANGAS].sort((a, b) => b.views - a.views).slice(0, 10);
    const latest = [...MANGAS].sort(
      (a, b) =>
        new Date(b.chapters[0].releasedAt).getTime() -
        new Date(a.chapters[0].releasedAt).getTime(),
    );
    const topRated = [...MANGAS].sort((a, b) => b.rating - a.rating).slice(0, 10);
    const continueIds = ["kurogane", "sertao-de-ferro", "crimson-court", "jade-emperor", "reborn-tactician", "folclore-urbano"];
    const continueReading = continueIds.map((id) => MANGAS.find((m) => m.id === id)!).filter(Boolean);
    return { popular, latest, topRated, continueReading };
  }, []);

  function choosePlan(plan: Plan) {
    setInvoice({
      title: `Assinatura ${plan.name}`,
      brl: plan.brl,
      xmr: xmrFromBrl(plan.brl),
      durationDays: plan.days,
      kind: "subscription",
    });
  }

  function donate(brl: number) {
    const amount = brl || 20;
    setInvoice({
      title: "Apoiar a plataforma",
      brl: amount,
      xmr: xmrFromBrl(amount),
      kind: "donation",
    });
  }

  function confirmInvoice() {
    if (!invoice) return;
    if (invoice.kind === "subscription" && invoice.durationDays) {
      setDaysLeft((d) => d + invoice.durationDays!);
      setIsPremium(true);
      setToast(`Assinatura ativa · +${invoice.durationDays} dias somados`);
    } else {
      setToast("Obrigado pelo apoio! 💜");
    }
    setInvoice(null);
  }

  function goPremium() {
    setReading(null);
    navigate("/planos");
  }

  function handleOpen(manga: Manga) {
    setReading(manga);
  }

  return (
    <div className="min-h-screen bg-[#07070b] text-white">
      <Header
        isPremium={isPremium}
        daysLeft={daysLeft}
        onLogoClick={() => navigate("/")}
      />

      <Routes>
        <Route path="/" element={<HomePage rows={rows} isPremium={isPremium} onOpen={handleOpen} />} />
        <Route path="/catalogo" element={<CatalogPage isPremium={isPremium} onOpen={handleOpen} />} />
        <Route path="/lancamentos" element={<LatestPage onOpen={handleOpen} />} />
        <Route path="/planos" element={<PlansPage isPremium={isPremium} daysLeft={daysLeft} onChoose={choosePlan} />} />
        <Route path="/apoiar" element={<DonatePage onDonate={donate} />} />
        <Route path="/admin" element={isAdmin ? <AdminDashboard /> : <AdminLogin onAuth={() => setIsAdmin(true)} />} />
      </Routes>

      <Footer />

      <button
        onClick={() => {
          if (isPremium) {
            setIsPremium(false);
            setDaysLeft(0);
            setToast("Visualizando experiência gratuita");
          } else {
            setIsPremium(true);
            setDaysLeft(30);
            setToast("Visualizando experiência de assinante");
          }
        }}
        className="fixed bottom-4 right-4 z-40 rounded-full border border-white/10 bg-[#12121c]/90 px-3 py-2 text-[11px] font-medium text-slate-400 shadow-lg backdrop-blur transition hover:text-white"
      >
        {isPremium ? "👁 Ver como Free" : "👁 Ver como Assinante"}
      </button>

      {reading && (
        <Reader
          manga={reading}
          isPremium={isPremium}
          onClose={() => setReading(null)}
          onWantPremium={goPremium}
        />
      )}

      {invoice && (
        <InvoiceModal
          title={invoice.title}
          brl={invoice.brl}
          xmr={invoice.xmr}
          durationDays={invoice.durationDays}
          onConfirm={confirmInvoice}
          onClose={() => setInvoice(null)}
        />
      )}

      {toast && <Toast message={toast} onDone={() => setToast(null)} />}
    </div>
  );
}

export default function App() {
  const [stage, setStage] = useState<Stage>("login");

  if (stage === "login") {
    return <Login onAuth={() => setStage("age")} />;
  }
  if (stage === "age") {
    return <AgeGate onVerified={() => setStage("app")} />;
  }

  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
