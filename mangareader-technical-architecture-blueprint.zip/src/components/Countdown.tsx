import { useEffect, useState } from "react";
import { formatCountdown } from "../utils/access";

type Props = {
  targetMs: number; // ms remaining at mount; recomputed via absolute time
  releasedAt: string;
  earlyAccessHours: number;
  className?: string;
  onExpire?: () => void;
};

export default function Countdown({
  releasedAt,
  earlyAccessHours,
  className = "",
  onExpire,
}: Props) {
  const compute = () =>
    Math.max(
      0,
      new Date(releasedAt).getTime() + earlyAccessHours * 3_600_000 - Date.now(),
    );
  const [ms, setMs] = useState(compute);

  useEffect(() => {
    const t = setInterval(() => {
      const next = compute();
      setMs(next);
      if (next <= 0) onExpire?.();
    }, 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [releasedAt]);

  return <span className={className}>{formatCountdown(ms)}</span>;
}
