import { useNavigate } from "react-router-dom";

export default function Footer() {
  const navigate = useNavigate();

  return (
    <footer className="border-t border-white/10 bg-[#05050a]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-fuchsia-600 text-lg">
                漫
              </div>
              <span className="text-sm font-bold text-white">MangaReader</span>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-slate-500">
              Mangás, manhwas, manhuas e novels. Leia onde e quando quiser.
            </p>
          </div>

          {[
            { h: "Navegar", l: ["Catálogo", "Lançamentos", "Em alta", "Melhor avaliados"] },
            { h: "Tipos", l: ["Mangás", "Manhwas", "Manhuas", "Novels", "BR"] },
            { h: "Conta", l: ["Planos", "Apoiar", "Continuar lendo", "Favoritos"] },
          ].map((col) => (
            <div key={col.h}>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                {col.h}
              </h4>
              <ul className="mt-3 space-y-2">
                {col.l.map((i) => (
                  <li
                    key={i}
                    onClick={() => {
                      if (i === "Catálogo") navigate("/catalogo");
                      else if (i === "Lançamentos") navigate("/lancamentos");
                      else if (i === "Planos") navigate("/planos");
                      else if (i === "Apoiar") navigate("/apoiar");
                    }}
                    className="cursor-pointer text-xs text-slate-500 transition hover:text-slate-300"
                  >
                    {i}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/5 pt-6 text-xs text-slate-600 sm:flex-row">
          <span>© {new Date().getFullYear()} MangaReader · Todos os direitos reservados</span>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              +12.000 capítulos
            </span>
            <a href="/admin" className="text-slate-700 transition hover:text-slate-500">
              Admin
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
