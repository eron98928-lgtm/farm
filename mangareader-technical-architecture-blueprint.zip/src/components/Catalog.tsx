import { useMemo, useState } from "react";
import {
  MANGAS,
  ALL_TYPES,
  ALL_STATUSES,
  ALL_GENRES,
  EARLY_ACCESS_HOURS,
  type Manga,
} from "../data/mangas";
import { isEarlyAccess } from "../utils/access";
import { getTypeBadge } from "../utils/typeBadge";
import Countdown from "./Countdown";
import AdSlot from "./AdSlot";

type Props = {
  isPremium: boolean;
  onOpen: (manga: Manga) => void;
};

function fmtViews(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return Math.round(n / 1000) + "k";
  return String(n);
}

const STATUS_STYLE: Record<string, string> = {
  Ativo: "text-emerald-300 bg-emerald-500/10",
  Hiato: "text-amber-300 bg-amber-500/10",
  Completo: "text-sky-300 bg-sky-500/10",
};

function MangaCard({
  manga,
  isPremium,
  onOpen,
}: {
  manga: Manga;
  isPremium: boolean;
  onOpen: (m: Manga) => void;
}) {
  const newest = manga.chapters[0];
  const early = isEarlyAccess(newest);

  return (
    <button
      onClick={() => onOpen(manga)}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-white/10 bg-white/[0.02] text-left transition hover:-translate-y-1 hover:border-violet-500/40 hover:shadow-xl hover:shadow-violet-950/40"
    >
      <div className={`relative aspect-[3/4] w-full bg-gradient-to-br ${manga.cover}`}>
        <div className="absolute inset-0 bg-black/10 transition group-hover:bg-black/0" />
        <span className={`absolute left-2 top-2 flex items-center gap-1 rounded-md ${getTypeBadge(manga.type).bg} px-1.5 py-0.5 text-[10px] font-bold text-white backdrop-blur`}>
          {getTypeBadge(manga.type).flag && <span>{getTypeBadge(manga.type).flag}</span>}
          {manga.type}
        </span>
        <div className="absolute right-2 top-2 flex flex-col items-end gap-1">
          {manga.mature && (
            <span className="rounded-md bg-red-600/90 px-1.5 py-0.5 text-[10px] font-bold text-white">
              18+
            </span>
          )}
          {early && (
            <span className="flex items-center gap-1 rounded-md bg-violet-600/90 px-1.5 py-0.5 text-[10px] font-bold text-white backdrop-blur">
              {isPremium ? "⚡ ANTECIPADO" : "🔒 EARLY"}
            </span>
          )}
        </div>
        <div className="absolute bottom-2 left-2 flex items-center gap-1 rounded-md bg-black/50 px-1.5 py-0.5 text-[11px] font-medium text-amber-300 backdrop-blur">
          ★ {manga.rating}
        </div>
        <div className="absolute inset-x-0 bottom-0 flex translate-y-2 items-center justify-center bg-gradient-to-t from-black/80 to-transparent pb-3 pt-8 text-xs font-semibold text-white opacity-0 transition group-hover:translate-y-0 group-hover:opacity-100">
          Ler agora →
        </div>
      </div>
      <div className="flex flex-1 flex-col p-3">
        <h3 className="line-clamp-1 text-sm font-semibold text-white">{manga.title}</h3>
        <p className="mt-0.5 line-clamp-1 text-xs text-slate-500">{manga.author}</p>
        <div className="mt-2 flex flex-wrap items-center gap-1">
          <span
            className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${STATUS_STYLE[manga.status]}`}
          >
            {manga.status}
          </span>
          {manga.genres.slice(0, 1).map((g) => (
            <span key={g} className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-400">
              {g}
            </span>
          ))}
        </div>
        {early && !isPremium && (
          <div className="mt-2 flex items-center gap-1 text-[10px] text-violet-300">
            <span>⏳</span>
            <span>Libera em </span>
            <Countdown
              targetMs={0}
              releasedAt={newest.releasedAt}
              earlyAccessHours={EARLY_ACCESS_HOURS}
              className="font-mono font-semibold"
            />
          </div>
        )}
        <div className="mt-auto flex items-center justify-between pt-3 text-[11px] text-slate-500">
          <span>👁 {fmtViews(manga.views)}</span>
          <span className="text-violet-400">{manga.chapters.length} caps</span>
        </div>
      </div>
    </button>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
        active
          ? "bg-violet-600 text-white"
          : "border border-white/10 bg-white/5 text-slate-400 hover:text-white"
      }`}
    >
      {children}
    </button>
  );
}

export default function Catalog({ isPremium, onOpen }: Props) {
  const [type, setType] = useState<string>("Todos");
  const [status, setStatus] = useState<string>("Todos");
  const [genres, setGenres] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"popular" | "rating" | "novos">("popular");

  function toggleGenre(g: string) {
    setGenres((prev) => (prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]));
  }

  function clearAll() {
    setType("Todos");
    setStatus("Todos");
    setGenres([]);
    setQuery("");
  }

  const filtered = useMemo(() => {
    const out = MANGAS.filter((m) => {
      const t = type === "Todos" || m.type === type;
      const s = status === "Todos" || m.status === status;
      const g = genres.length === 0 || genres.every((x) => m.genres.includes(x));
      const q =
        !query ||
        m.title.toLowerCase().includes(query.toLowerCase()) ||
        m.author.toLowerCase().includes(query.toLowerCase());
      return t && s && g && q;
    });
    out.sort((a, b) => {
      if (sort === "rating") return b.rating - a.rating;
      if (sort === "novos")
        return (
          new Date(b.chapters[0].releasedAt).getTime() -
          new Date(a.chapters[0].releasedAt).getTime()
        );
      return b.views - a.views;
    });
    return out;
  }, [type, status, genres, query, sort]);

  const activeCount =
    (type !== "Todos" ? 1 : 0) + (status !== "Todos" ? 1 : 0) + genres.length;

  return (
    <section id="catalog" className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
          Descubra sua próxima leitura
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Explore por tipo, gênero e status. Novos títulos toda semana.
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
        {/* Sidebar filters */}
        <aside className="lg:sticky lg:top-20 lg:h-fit">
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Filtros</h3>
              {activeCount > 0 && (
                <button
                  onClick={clearAll}
                  className="text-[11px] font-medium text-violet-400 hover:text-violet-300"
                >
                  Limpar ({activeCount})
                </button>
              )}
            </div>

            <div className="mt-5">
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Tipo
              </p>
              <div className="flex flex-wrap gap-2">
                <Chip active={type === "Todos"} onClick={() => setType("Todos")}>
                  Todos
                </Chip>
                {ALL_TYPES.map((t) => (
                  <Chip key={t} active={type === t} onClick={() => setType(t)}>
                    {t}
                  </Chip>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Estado
              </p>
              <div className="flex flex-wrap gap-2">
                <Chip active={status === "Todos"} onClick={() => setStatus("Todos")}>
                  Todos
                </Chip>
                {ALL_STATUSES.map((s) => (
                  <Chip key={s} active={status === s} onClick={() => setStatus(s)}>
                    {s}
                  </Chip>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Gêneros
              </p>
              <div className="flex flex-wrap gap-2">
                {ALL_GENRES.map((g) => (
                  <Chip key={g} active={genres.includes(g)} onClick={() => toggleGenre(g)}>
                    {g}
                  </Chip>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* Results */}
        <div>
          <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative w-full sm:max-w-xs">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar título ou autor…"
                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none transition focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20"
              />
              <span className="pointer-events-none absolute right-3 top-2.5 text-slate-500">🔍</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">{filtered.length} resultados</span>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as typeof sort)}
                className="rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-xs text-slate-300 outline-none focus:border-violet-500"
              >
                <option value="popular">Mais populares</option>
                <option value="rating">Melhor avaliados</option>
                <option value="novos">Lançamentos</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {filtered.map((m) => (
              <MangaCard key={m.id} manga={m} isPremium={isPremium} onOpen={onOpen} />
            ))}
          </div>

          {filtered.length === 0 && (
            <p className="py-16 text-center text-sm text-slate-500">
              Nada encontrado com esses filtros.{" "}
              <button onClick={clearAll} className="text-violet-400 hover:underline">
                Limpar filtros
              </button>
            </p>
          )}

          {!isPremium && (
            <div className="mt-8">
              <AdSlot label="Espaço publicitário" className="min-h-[120px] w-full" />
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
