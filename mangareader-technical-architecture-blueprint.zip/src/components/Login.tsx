import { useState } from "react";

type Props = {
  onAuth: () => void;
};

export default function Login({ onAuth }: Props) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [loading, setLoading] = useState(false);

  const valid = /\S+@\S+\.\S+/.test(email) && pw.length >= 6;

  function submit() {
    if (!valid) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onAuth();
    }, 900);
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#07070b] px-4">
      {/* ambient glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="animate-float-slow absolute -left-20 top-10 h-72 w-72 rounded-full bg-violet-600/20 blur-3xl" />
        <div
          className="animate-float-slow absolute -right-10 bottom-10 h-80 w-80 rounded-full bg-fuchsia-600/15 blur-3xl"
          style={{ animationDelay: "2s" }}
        />
      </div>

      <div className="animate-fade-up relative w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-600 text-2xl shadow-lg shadow-violet-900/40">
            漫
          </div>
          <h1 className="mt-4 text-xl font-bold text-white">MangaReader</h1>
          <p className="text-[11px] font-medium uppercase tracking-widest text-violet-400/80">
            Sua biblioteca de mangás
          </p>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur">
          <div className="mb-5 grid grid-cols-2 gap-1 rounded-lg border border-white/10 bg-black/30 p-1">
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-md py-2 text-sm font-medium transition ${
                  mode === m ? "bg-violet-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                {m === "login" ? "Entrar" : "Criar conta"}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-slate-400">E-mail</span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@exemplo.com"
                className="w-full rounded-lg border border-white/10 bg-black/40 px-4 py-2.5 text-sm text-white outline-none transition focus:border-violet-500 focus:ring-2 focus:ring-violet-500/30"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-slate-400">Senha</span>
              <input
                type="password"
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-lg border border-white/10 bg-black/40 px-4 py-2.5 text-sm text-white outline-none transition focus:border-violet-500 focus:ring-2 focus:ring-violet-500/30"
              />
            </label>

            {mode === "register" && (
              <p className="rounded-lg border border-white/5 bg-black/30 p-3 text-[11px] leading-relaxed text-slate-400">
                Milhares de mangás, manhwas e novels esperando por você. Crie sua conta e comece a
                ler em segundos.
              </p>
            )}

            <button
              onClick={submit}
              disabled={!valid || loading}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-3 text-sm font-semibold text-white transition enabled:hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {loading ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              ) : mode === "login" ? (
                "Entrar"
              ) : (
                "Continuar"
              )}
            </button>

            <button
              onClick={onAuth}
              className="w-full text-center text-xs text-slate-500 transition hover:text-slate-300"
            >
              Explorar como visitante →
            </button>
          </div>
        </div>

        <p className="mt-6 text-center text-[11px] text-slate-600">
          Mais de 12.000 capítulos · atualizados todo dia
        </p>
      </div>
    </div>
  );
}
