import { useNavigate } from "react-router-dom";

type Props = {
  isPremium: boolean;
  daysLeft: number;
  onLogoClick: () => void;
};

const NAV = [
  { label: "Início", path: "/" },
  { label: "Catálogo", path: "/catalogo" },
  { label: "Lançamentos", path: "/lancamentos" },
  { label: "Planos", path: "/planos" },
  { label: "Apoiar", path: "/apoiar" },
];

export default function Header({ isPremium, daysLeft, onLogoClick }: Props) {
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#07070b]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        <button onClick={onLogoClick} className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-fuchsia-600 text-lg shadow-lg shadow-violet-900/40">
            漫
          </div>
          <div className="text-left leading-none">
            <div className="text-[15px] font-bold tracking-tight text-white">MangaReader</div>
            <div className="text-[10px] font-medium uppercase tracking-widest text-violet-400/80">
              Manga · Manhwa · Manhua · Novel · BR
            </div>
          </div>
        </button>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((n) => (
            <button
              key={n.path}
              onClick={() => navigate(n.path)}
              className="rounded-md px-3 py-2 text-sm font-medium text-slate-300 transition hover:bg-white/5 hover:text-white"
            >
              {n.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {isPremium ? (
            <span className="hidden items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1.5 text-xs font-semibold text-amber-300 sm:flex">
              ⭐ Assinante · {daysLeft}d
            </span>
          ) : (
            <span className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-400 sm:flex">
              Conta Free
            </span>
          )}
          <button
            onClick={() => navigate("/planos")}
            className="rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90"
          >
            Apoiar
          </button>
        </div>
      </div>
    </header>
  );
}
