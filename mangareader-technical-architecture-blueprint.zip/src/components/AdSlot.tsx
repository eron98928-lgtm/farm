type Props = {
  label?: string;
  className?: string;
};

// Static, non-intrusive ad placement with reserved space so the page never
// jumps while the ad loads. Never rendered for assinantes.
export default function AdSlot({ label = "Publicidade", className = "" }: Props) {
  return (
    <div
      className={`flex flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-white/[0.02] text-center ${className}`}
      style={{ minHeight: 250 }}
      aria-label="ad-slot"
    >
      <span className="text-[10px] font-medium uppercase tracking-widest text-slate-600">
        {label}
      </span>
      <span className="mt-1 text-xs text-slate-500">Espaço de anúncio</span>
    </div>
  );
}
