import { useEffect, useState } from "react";
import { MANGAS, type Manga } from "../data/mangas";
import { getTypeBadge } from "../utils/typeBadge";

type Props = {
  onRead: (m: Manga) => void;
};

// Spotlight the top-rated titles
const FEATURED = [...MANGAS].sort((a, b) => b.rating - a.rating).slice(0, 4);

function fmtViews(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return Math.round(n / 1000) + "k";
  return String(n);
}

export default function Hero({ onRead }: Props) {
  const [i, setI] = useState(0);
  const m = FEATURED[i];

  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % FEATURED.length), 6000);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative overflow-hidden">
      {/* dynamic backdrop based on featured cover */}
      <div className={`absolute inset-0 bg-gradient-to-br ${m.cover} opacity-25 transition-all duration-700`} />
      <div className="absolute inset-0 bg-gradient-to-t from-[#07070b] via-[#07070b]/80 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#07070b] via-transparent to-transparent" />

      <div className="relative mx-auto max-w-7xl px-4 pb-12 pt-14 sm:px-6 sm:pb-16 sm:pt-20">
        <div className="grid items-center gap-10 md:grid-cols-[1fr_320px]">
          {/* text */}
          <div key={m.id} className="animate-fade-up max-w-xl">
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <span className="rounded-md bg-violet-600 px-2 py-1 text-[11px] font-bold text-white">
                EM DESTAQUE
              </span>
              <span className={`flex items-center gap-1 rounded-md ${getTypeBadge(m.type).bg} px-2 py-1 text-[11px] font-medium text-white backdrop-blur`}>
                {getTypeBadge(m.type).flag && <span>{getTypeBadge(m.type).flag}</span>}
                {m.type}
              </span>
              <span className="flex items-center gap-1 text-xs font-medium text-amber-300">
                ★ {m.rating}
              </span>
            </div>

            <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-white sm:text-6xl">
              {m.title}
            </h1>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              {m.genres.slice(0, 3).map((g) => (
                <span key={g} className="rounded-full bg-white/5 px-3 py-1 text-xs text-slate-300">
                  {g}
                </span>
              ))}
            </div>

            <p className="mt-5 max-w-lg text-base leading-relaxed text-slate-300">
              {m.synopsis}
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onRead(m)}
                className="rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-violet-900/40 transition hover:opacity-90"
              >
                ▶ Começar a ler
              </button>
              <a
                href="#catalog"
                className="rounded-xl border border-white/15 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white transition hover:bg-white/10"
              >
                Ver catálogo
              </a>
              <span className="text-xs text-slate-400">
                👁 {fmtViews(m.views)} leitores · {m.chapters.length} capítulos
              </span>
            </div>

            {/* slide indicators */}
            <div className="mt-8 flex gap-2">
              {FEATURED.map((f, idx) => (
                <button
                  key={f.id}
                  onClick={() => setI(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === i ? "w-8 bg-violet-500" : "w-3 bg-white/20 hover:bg-white/40"
                  }`}
                  aria-label={f.title}
                />
              ))}
            </div>
          </div>

          {/* cover art */}
          <button
            onClick={() => onRead(m)}
            className="group relative mx-auto hidden w-full max-w-[280px] md:block"
          >
            <div
              key={m.id}
              className={`animate-fade-up aspect-[3/4] w-full overflow-hidden rounded-2xl bg-gradient-to-br ${m.cover} shadow-2xl ring-1 ring-white/10 transition group-hover:scale-[1.02]`}
            >
              <div className="flex h-full items-center justify-center">
                <span className="text-8xl opacity-30">漫</span>
              </div>
            </div>
            <span className="absolute -bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-medium text-white opacity-0 backdrop-blur transition group-hover:opacity-100">
              Ler agora →
            </span>
          </button>
        </div>
      </div>
    </section>
  );
}
