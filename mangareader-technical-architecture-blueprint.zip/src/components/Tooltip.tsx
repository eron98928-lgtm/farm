import { useState, type ReactNode } from "react";

type Props = {
  content: ReactNode;
  children: ReactNode;
};

export default function Tooltip({ content, children }: Props) {
  const [open, setOpen] = useState(false);
  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      tabIndex={0}
    >
      {children}
      {open && (
        <span className="animate-fade-up absolute bottom-full left-1/2 z-50 mb-2 w-60 -translate-x-1/2 rounded-lg border border-white/10 bg-[#15151f] px-3 py-2 text-left text-xs leading-relaxed text-slate-300 shadow-xl">
          {content}
          <span className="absolute left-1/2 top-full h-2 w-2 -translate-x-1/2 -translate-y-1 rotate-45 border-b border-r border-white/10 bg-[#15151f]" />
        </span>
      )}
    </span>
  );
}
