import { useState } from "react";

type Props = {
  onVerified: () => void;
};

function maskCpf(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  return d
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

export default function AgeGate({ onVerified }: Props) {
  const [cpf, setCpf] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const digits = cpf.replace(/\D/g, "");
  const valid = digits.length === 11;

  async function handleVerify() {
    if (!valid) return;
    setLoading(true);
    // Simulate FonteData partner validation latency
    await new Promise((r) => setTimeout(r, 1100));
    setDone(true);
    setLoading(false);
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="animate-fade-up w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-[#0d0d16] shadow-2xl">
        <div className="border-b border-white/10 bg-gradient-to-r from-violet-600/20 to-fuchsia-600/10 px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/20 text-xl">
              🛡️
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Verificação de Idade</h2>
              <p className="text-xs text-slate-400">Compromisso ético · Lei 15.211/2025 (ECA Digital)</p>
            </div>
          </div>
        </div>

        <div className="space-y-4 px-6 py-6">
          {!done ? (
            <>
              <p className="text-sm leading-relaxed text-slate-300">
                Confirme sua maioridade para liberar o catálogo completo. Validação rápida e única.
              </p>

              <label className="block">
                <span className="mb-1.5 block text-xs font-medium text-slate-400">CPF</span>
                <input
                  inputMode="numeric"
                  value={cpf}
                  onChange={(e) => setCpf(maskCpf(e.target.value))}
                  placeholder="000.000.000-00"
                  className="w-full rounded-lg border border-white/10 bg-black/40 px-4 py-3 text-sm text-white outline-none transition focus:border-violet-500 focus:ring-2 focus:ring-violet-500/30"
                />
              </label>

              <p className="text-[11px] leading-relaxed text-slate-500">
                Exigido por lei (ECA Digital). Usado apenas para confirmar sua idade.
              </p>

              <button
                onClick={handleVerify}
                disabled={!valid || loading}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-3 text-sm font-semibold text-white transition enabled:hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {loading ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                    Validando com a FonteData…
                  </>
                ) : (
                  "Verificar e continuar"
                )}
              </button>
            </>
          ) : (
            <>
              <div className="flex items-center gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-3">
                <span className="text-xl">✅</span>
                <div>
                  <p className="text-sm font-semibold text-emerald-300">Idade verificada</p>
                  <p className="text-xs text-emerald-400/70">Maioridade confirmada · acesso liberado</p>
                </div>
              </div>

              <p className="text-[11px] leading-relaxed text-slate-500">
                Tudo certo! Bom proveito na leitura. 📚
              </p>

              <button
                onClick={onVerified}
                className="w-full rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-3 text-sm font-semibold text-white transition hover:opacity-90"
              >
                Entrar na plataforma →
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
