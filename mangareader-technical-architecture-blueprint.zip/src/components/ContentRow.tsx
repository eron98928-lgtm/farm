import { EARLY_ACCESS_HOURS, type Manga } from "../data/mangas";
import { isEarlyAccess } from "../utils/access";
import { getTypeBadge } from "../utils/typeBadge";
import Countdown from "./Countdown";
import { useNavigate } from "react-router-dom";

type Props = {
  title: string;
  subtitle?: string;
  mangas: Manga[];
  isPremium: boolean;
  onOpen: (m: Manga) => void;
  showProgress?: boolean;
};

function fmtViews(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return Math.round(n / 1000) + "k";
  return String(n);
}

export default function ContentRow({
  title,
  subtitle,
  mangas,
  isPremium,
  onOpen,
  showProgress,
}: Props) {
  const navigate = useNavigate();
  if (mangas.length === 0) return null;

  return (
    <section className="mx-auto max-w-7xl px-4 py-7 sm:px-6">
      <div className="mb-4 flex items-end justify-between">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white sm:text-xl">{title}</h2>
          {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
        </div>
        <button
          onClick={() => navigate("/catalogo")}
          className="text-xs font-medium text-violet-400 hover:text-violet-300"
        >
          Ver tudo →
        </button>
      </div>

      <div className="no-scrollbar -mx-4 flex gap-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
        {mangas.map((m, idx) => {
          const newest = m.chapters[0];
          const early = isEarlyAccess(newest);
          const progress = showProgress ? 15 + ((idx * 27) % 70) : 0;
          return (
            <button
              key={m.id}
              onClick={() => onOpen(m)}
              className="group w-[148px] shrink-0 text-left sm:w-[160px]"
            >
              <div
                className={`relative aspect-[3/4] w-full overflow-hidden rounded-xl bg-gradient-to-br ${m.cover} ring-1 ring-white/10 transition group-hover:ring-violet-500/50`}
              >
                <div className="flex h-full items-center justify-center">
                  <span className="text-5xl opacity-25">漫</span>
                </div>
                <span className={`absolute left-2 top-2 flex items-center gap-1 rounded-md ${getTypeBadge(m.type).bg} px-1.5 py-0.5 text-[10px] font-bold text-white backdrop-blur`}>
                  {getTypeBadge(m.type).flag && <span>{getTypeBadge(m.type).flag}</span>}
                  {m.type}
                </span>
                {m.mature && (
                  <span className="absolute right-2 top-2 rounded-md bg-red-600/90 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    18+
                  </span>
                )}
                {early && (
                  <span className="absolute bottom-2 left-2 rounded-md bg-violet-600/90 px-1.5 py-0.5 text-[10px] font-bold text-white backdrop-blur">
                    {isPremium ? "⚡ NOVO" : "🔒 EARLY"}
                  </span>
                )}
                <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-md bg-black/55 px-1.5 py-0.5 text-[10px] font-medium text-amber-300 backdrop-blur">
                  ★ {m.rating}
                </div>

                {showProgress && (
                  <div className="absolute inset-x-0 bottom-0 h-1 bg-black/40">
                    <div className="h-full bg-violet-500" style={{ width: `${progress}%` }} />
                  </div>
                )}
              </div>

              <h3 className="mt-2 line-clamp-1 text-sm font-semibold text-white">{m.title}</h3>
              {showProgress ? (
                <p className="mt-0.5 text-[11px] text-slate-500">
                  Cap. {newest.number} · {progress}% lido
                </p>
              ) : early && !isPremium ? (
                <p className="mt-0.5 flex items-center gap-1 text-[11px] text-violet-300">
                  ⏳ libera em{" "}
                  <Countdown
                    targetMs={0}
                    releasedAt={newest.releasedAt}
                    earlyAccessHours={EARLY_ACCESS_HOURS}
                    className="font-mono font-semibold"
                  />
                </p>
              ) : (
                <p className="mt-0.5 text-[11px] text-slate-500">
                  Cap. {newest.number} · 👁 {fmtViews(m.views)}
                </p>
              )}
            </button>
          );
        })}
      </div>
    </section>
  );
}
