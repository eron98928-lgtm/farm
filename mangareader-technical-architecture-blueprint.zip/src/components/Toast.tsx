import { useEffect } from "react";

type Props = {
  message: string;
  onDone: () => void;
};

export default function Toast({ message, onDone }: Props) {
  useEffect(() => {
    const t = setTimeout(onDone, 3200);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div className="fixed bottom-6 left-1/2 z-[120] -translate-x-1/2">
      <div className="animate-fade-up flex items-center gap-2.5 rounded-xl border border-emerald-500/30 bg-[#0d0d16] px-5 py-3 shadow-2xl">
        <span className="text-lg">✅</span>
        <span className="text-sm font-medium text-white">{message}</span>
      </div>
    </div>
  );
}
