import { PLANS, type Plan, xmrFromBrl } from "../data/plans";
import Tooltip from "./Tooltip";

type Props = {
  isPremium: boolean;
  daysLeft: number;
  onChoose: (plan: Plan) => void;
};

export default function Plans({ isPremium, daysLeft, onChoose }: Props) {
  return (
    <section id="plans" className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
          Leia sem limites
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-slate-400">
          Capítulos novos na hora, sem anúncios e sem espera. Apoie a plataforma e os tradutores —
          renovação manual, do seu jeito.
        </p>

        <div className="mt-5 inline-flex items-center gap-2 text-xs text-slate-400">
          <span>💡 Renovação cumulativa</span>
          <Tooltip content="Renovar antes do prazo nunca faz você perder dias. Os novos dias são somados ao seu saldo — ex.: 10 dias restantes + 30 do plano Mensal = 40 dias.">
            <span className="flex h-4 w-4 cursor-help items-center justify-center rounded-full border border-white/20 text-[10px] text-slate-400">
              ?
            </span>
          </Tooltip>
        </div>
      </div>

      {isPremium && (
        <div className="mx-auto mt-8 max-w-md rounded-xl border border-amber-400/30 bg-amber-400/10 px-5 py-4 text-center text-sm text-amber-200">
          ⭐ Assinatura ativa · <span className="font-bold">{daysLeft} dias</span> restantes.
        </div>
      )}

      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {PLANS.map((plan) => (
          <div
            key={plan.id}
            className={`relative flex flex-col rounded-2xl border p-6 transition ${
              plan.highlight
                ? "border-violet-500/50 bg-gradient-to-b from-violet-600/10 to-transparent shadow-xl shadow-violet-950/40"
                : "border-white/10 bg-white/[0.02]"
            }`}
          >
            {plan.highlight && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 px-3 py-1 text-[11px] font-bold text-white">
                MAIS POPULAR
              </span>
            )}
            <h3 className="text-lg font-bold text-white">{plan.name}</h3>
            <p className="text-xs text-slate-500">{plan.duration} de acesso</p>

            <div className="mt-5 flex items-end gap-1">
              <span className="text-3xl font-extrabold text-white">R$ {plan.brl}</span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              ≈ {xmrFromBrl(plan.brl)} XMR
            </div>

            <ul className="mt-6 flex-1 space-y-2.5">
              {plan.perks.map((p) => (
                <li key={p} className="flex items-start gap-2 text-sm text-slate-300">
                  <span className="mt-0.5 text-emerald-400">✓</span>
                  <span>{p}</span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => onChoose(plan)}
              className={`mt-7 w-full rounded-xl px-4 py-3 text-sm font-semibold transition ${
                plan.highlight
                  ? "bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white hover:opacity-90"
                  : "border border-white/15 bg-white/5 text-white hover:bg-white/10"
              }`}
            >
              Assinar
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}
