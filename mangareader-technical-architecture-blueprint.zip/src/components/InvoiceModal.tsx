import { useEffect, useMemo, useState } from "react";

type Props = {
  title: string;
  brl: number;
  xmr: string;
  durationDays?: number;
  onConfirm: () => void; // simulate webhook confirmation
  onClose: () => void;
};

// Generate a plausible-looking Monero subaddress (8xxxx...) for the demo.
function genSubaddress() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz123456789";
  const arr = new Uint8Array(94);
  crypto.getRandomValues(arr);
  return "8" + Array.from(arr).map((b) => chars[b % chars.length]).join("").slice(0, 94);
}

// Deterministic pseudo-QR grid (purely decorative).
function QrGrid({ seed }: { seed: string }) {
  const cells = useMemo(() => {
    const size = 25;
    let h = 0;
    for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
    const out: boolean[] = [];
    for (let i = 0; i < size * size; i++) {
      h = (h * 1103515245 + 12345) & 0x7fffffff;
      out.push((h >> 8) % 100 < 48);
    }
    return out;
  }, [seed]);
  const size = 25;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="h-44 w-44" shapeRendering="crispEdges">
      <rect width={size} height={size} fill="#fff" />
      {cells.map((on, i) =>
        on ? (
          <rect key={i} x={i % size} y={Math.floor(i / size)} width={1} height={1} fill="#0a0a0a" />
        ) : null,
      )}
      {/* finder squares */}
      {[
        [0, 0],
        [size - 7, 0],
        [0, size - 7],
      ].map(([x, y], k) => (
        <g key={k}>
          <rect x={x} y={y} width={7} height={7} fill="#0a0a0a" />
          <rect x={x + 1} y={y + 1} width={5} height={5} fill="#fff" />
          <rect x={x + 2} y={y + 2} width={3} height={3} fill="#7c3aed" />
        </g>
      ))}
    </svg>
  );
}

export default function InvoiceModal({
  title,
  brl,
  xmr,
  durationDays,
  onConfirm,
  onClose,
}: Props) {
  const [address] = useState(genSubaddress);
  const [secs, setSecs] = useState(15 * 60);
  const [status, setStatus] = useState<"pending" | "detecting" | "paid">("pending");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (status === "paid") return;
    const t = setInterval(() => setSecs((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [status]);

  const mm = String(Math.floor(secs / 60)).padStart(2, "0");
  const ss = String(secs % 60).padStart(2, "0");

  function simulate() {
    setStatus("detecting");
    setTimeout(() => {
      setStatus("paid");
      setTimeout(onConfirm, 1400);
    }, 2200);
  }

  function copy() {
    navigator.clipboard?.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="fixed inset-0 z-[95] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="animate-fade-up w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-[#0d0d16] shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 bg-gradient-to-r from-orange-600/20 to-amber-500/10 px-6 py-4">
          <div className="flex items-center gap-2">
            <span className="text-lg">◎</span>
            <div>
              <h2 className="text-sm font-semibold text-white">{title}</h2>
              <p className="text-[11px] text-slate-400">Pagamento privado · Monero</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-500 transition hover:text-white">
            ✕
          </button>
        </div>

        <div className="px-6 py-6">
          {status === "paid" ? (
            <div className="flex flex-col items-center py-8 text-center">
              <div className="flex h-16 w-16 animate-pulse-ring items-center justify-center rounded-full bg-emerald-500/20 text-3xl">
                ✅
              </div>
              <h3 className="mt-5 text-lg font-bold text-emerald-300">Pagamento confirmado</h3>
              <p className="mt-1 text-sm text-slate-400">
                Recebemos sua contribuição com segurança e privacidade.
              </p>
              {durationDays && (
                <p className="mt-3 rounded-lg bg-white/5 px-4 py-2 text-sm text-white">
                  + {durationDays} dias adicionados ao seu saldo
                </p>
              )}
            </div>
          ) : (
            <>
              <div className="flex flex-col items-center">
                <div className="rounded-xl border border-white/10 bg-white p-2">
                  <QrGrid seed={address} />
                </div>
                <div className="mt-4 text-center">
                  <div className="text-2xl font-bold text-white">◎ {xmr} XMR</div>
                  <div className="text-xs text-slate-500">≈ R$ {brl}</div>
                </div>
              </div>

              <div className="mt-5">
                <span className="mb-1.5 block text-xs font-medium text-slate-400">
                  Endereço único desta transação
                </span>
                <button
                  onClick={copy}
                  className="group flex w-full items-center gap-2 rounded-lg border border-white/10 bg-black/40 px-3 py-2.5 text-left"
                >
                  <code className="flex-1 truncate font-mono text-[11px] text-orange-300">
                    {address}
                  </code>
                  <span className="shrink-0 text-xs text-slate-400 group-hover:text-white">
                    {copied ? "✓ copiado" : "copiar"}
                  </span>
                </button>
              </div>

              <div className="mt-4 flex items-center justify-between rounded-lg border border-white/5 bg-black/30 px-3 py-2.5 text-xs">
                <span className="text-slate-400">Expira em</span>
                <span className="font-mono font-semibold text-amber-300">
                  {mm}:{ss}
                </span>
              </div>

              <button
                onClick={simulate}
                disabled={status === "detecting"}
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 px-4 py-3 text-sm font-semibold text-white transition enabled:hover:opacity-90 disabled:opacity-60"
              >
                {status === "detecting" ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                    Confirmando seu pagamento…
                  </>
                ) : (
                  "Simular pagamento (demo)"
                )}
              </button>
              <p className="mt-3 text-center text-[11px] text-slate-600">
                Demonstração · nenhuma transação real é realizada.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
