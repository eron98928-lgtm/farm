import { xmrFromBrl } from "../data/plans";

type Props = {
  onDonate: (brl: number) => void;
};

const AMOUNTS = [5, 15, 50, 100];

export default function Donate({ onDonate }: Props) {
  return (
    <section id="donate" className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-600/10 blur-3xl" />
      </div>
      <div className="relative mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-8 sm:p-12">
          <div className="grid items-center gap-10 md:grid-cols-2">
            <div>
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-violet-500/30 bg-violet-500/10 px-3 py-1 text-xs font-semibold text-violet-300">
                ❤️ Apoie os tradutores
              </div>
              <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
                Ajude a manter o catálogo crescendo
              </h2>
              <p className="mt-4 text-sm leading-relaxed text-slate-400">
                Cada doação ajuda os grupos de tradução a lançarem mais capítulos, mais rápido — e
                mantém a plataforma no ar para todo mundo ler de graça.
              </p>

              <ul className="mt-6 space-y-2 text-sm text-slate-300">
                {[
                  "Mais capítulos traduzidos por mês",
                  "Novos títulos adicionados ao catálogo",
                  "Servidores rápidos e estáveis",
                ].map((t) => (
                  <li key={t} className="flex items-center gap-2">
                    <span className="text-violet-400">✓</span> {t}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-white/10 bg-black/30 p-6">
              <p className="text-sm font-semibold text-white">Escolha um valor</p>
              <div className="mt-4 grid grid-cols-2 gap-3">
                {AMOUNTS.map((a) => (
                  <button
                    key={a}
                    onClick={() => onDonate(a)}
                    className="group rounded-xl border border-white/10 bg-white/[0.03] px-4 py-4 text-center transition hover:border-violet-500/50 hover:bg-violet-500/5"
                  >
                    <div className="text-lg font-bold text-white">R$ {a}</div>
                    <div className="mt-0.5 text-xs text-slate-500">≈ {xmrFromBrl(a)} XMR</div>
                  </button>
                ))}
              </div>
              <button
                onClick={() => onDonate(0)}
                className="mt-4 w-full rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-4 py-3 text-sm font-semibold text-white transition hover:opacity-90"
              >
                Doar outro valor
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
