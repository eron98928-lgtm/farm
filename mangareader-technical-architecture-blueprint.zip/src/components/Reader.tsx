import { useEffect, useMemo, useState } from "react";
import { EARLY_ACCESS_HOURS, type Chapter, type Manga } from "../data/mangas";
import { isLocked, isEarlyAccess } from "../utils/access";
import Countdown from "./Countdown";
import AdSlot from "./AdSlot";

type Props = {
  manga: Manga;
  isPremium: boolean;
  onClose: () => void;
  onWantPremium: () => void;
};

function PageCanvas({ index, total, hue }: { index: number; total: number; hue: string }) {
  return (
    <div
      className={`relative mx-auto flex aspect-[2/3] w-full max-w-2xl items-center justify-center overflow-hidden rounded-lg bg-gradient-to-b ${hue}`}
    >
      <div className="absolute inset-0 opacity-20 [background-image:repeating-linear-gradient(45deg,#fff_0_2px,transparent_2px_22px)]" />
      <div className="relative text-center">
        <div className="text-6xl opacity-30">漫</div>
        <div className="mt-3 text-sm font-semibold text-white/80">
          Página {index} / {total}
        </div>
      </div>
    </div>
  );
}

export default function Reader({ manga, isPremium, onClose, onWantPremium }: Props) {
  const firstUnlocked = manga.chapters.find((c) => !isLocked(c, isPremium)) ?? manga.chapters[0];
  const [active, setActive] = useState<Chapter>(firstUnlocked);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const locked = isLocked(active, isPremium);
  const hues = useMemo(
    () => [
      "from-slate-800 to-slate-950",
      "from-indigo-900 to-slate-950",
      "from-violet-900 to-slate-950",
      "from-zinc-800 to-zinc-950",
    ],
    [],
  );

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  function toggleSidebar() {
    setSidebarOpen((prev) => !prev);
  }

  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-[#06060a]">
      {/* top bar */}
      <div className="flex items-center justify-between border-b border-white/10 bg-[#0a0a12] px-4 py-3">
        <div className="flex min-w-0 items-center gap-3">
          <button
            onClick={onClose}
            className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-slate-300 transition hover:bg-white/10"
          >
            ← Voltar
          </button>
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold text-white">{manga.title}</div>
            <div className="truncate text-xs text-slate-500">
              {active.title} · {active.pages} páginas
            </div>
          </div>
        </div>
        {isPremium ? (
          <span className="rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-1 text-xs font-semibold text-amber-300">
            ⭐ Assinante
          </span>
        ) : (
          <button
            onClick={onWantPremium}
            className="rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 px-3 py-1.5 text-xs font-semibold text-white"
          >
            Tornar-se Assinante
          </button>
        )}
      </div>

      <div className="flex min-h-0 flex-1">
        {/* chapter sidebar */}
        <aside
          className={`${
            sidebarOpen ? "w-60" : "w-0"
          } hidden shrink-0 overflow-hidden border-r border-white/10 bg-[#08080f] transition-all duration-300 md:block`}
        >
          <div className="flex items-center justify-between px-4 py-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Capítulos
            </span>
            <button
              onClick={toggleSidebar}
              className="rounded p-1 text-slate-400 transition hover:bg-white/5 hover:text-white"
              title={sidebarOpen ? "Recolher" : "Expandir"}
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
          </div>
          <div className={`${sidebarOpen ? "opacity-100" : "opacity-0"} transition-opacity duration-200`}>
            <ul className="pb-6">
            {manga.chapters.map((c) => {
              const lk = isLocked(c, isPremium);
              const early = isEarlyAccess(c);
              return (
                <li key={c.id}>
                  <button
                    onClick={() => setActive(c)}
                    className={`flex w-full items-center justify-between gap-2 px-4 py-2.5 text-left text-sm transition ${
                      active.id === c.id
                        ? "bg-violet-600/15 text-white"
                        : "text-slate-400 hover:bg-white/5 hover:text-white"
                    }`}
                  >
                    <span className="truncate">{c.title}</span>
                    {early ? (
                      <span
                        className={`shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold ${
                          lk ? "bg-violet-600/30 text-violet-200" : "bg-amber-500/20 text-amber-300"
                        }`}
                      >
                        {lk ? "EARLY" : "⚡"}
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-600">{c.pages}p</span>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
          </div>
        </aside>

        {/* Toggle button when sidebar is closed */}
        {!sidebarOpen && (
          <button
            onClick={toggleSidebar}
            className="absolute left-4 top-20 z-10 rounded-lg border border-white/10 bg-[#08080f]/90 p-2 text-slate-400 shadow-lg backdrop-blur transition hover:text-white"
            title="Expandir capítulos"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 18l6-6-6-6" />
            </svg>
          </button>
        )}

        {/* reading pane */}
        <main className="min-w-0 flex-1 overflow-y-auto">
          <div className="mx-auto flex max-w-5xl gap-6 px-4 py-6">
            <div className="min-w-0 flex-1 space-y-4">
              {locked ? (
                <div className="mx-auto flex max-w-xl flex-col items-center rounded-2xl border border-white/10 bg-white/[0.02] px-6 py-16 text-center">
                  <div className="text-5xl">🔒</div>
                  <span className="mt-4 rounded-full bg-violet-600/20 px-3 py-1 text-xs font-bold text-violet-200">
                    EARLY ACCESS
                  </span>
                  <h3 className="mt-4 text-xl font-bold text-white">Capítulo recém-lançado</h3>
                  <p className="mt-2 text-sm text-slate-400">
                    Este capítulo está em janela de acesso antecipado para assinantes. Leitores
                    gratuitos podem ler em:
                  </p>
                  <div className="mt-4 rounded-xl border border-violet-500/30 bg-violet-600/10 px-6 py-3">
                    <Countdown
                      targetMs={0}
                      releasedAt={active.releasedAt}
                      earlyAccessHours={EARLY_ACCESS_HOURS}
                      className="font-mono text-2xl font-bold text-violet-200"
                    />
                  </div>
                  <button
                    onClick={onWantPremium}
                    className="mt-6 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 px-6 py-3 text-sm font-semibold text-white transition hover:opacity-90"
                  >
                    Ler agora como assinante →
                  </button>
                  <button
                    onClick={() => {
                      const next = manga.chapters.find((c) => !isLocked(c, isPremium));
                      if (next) setActive(next);
                    }}
                    className="mt-3 text-xs text-slate-500 underline-offset-2 hover:underline"
                  >
                    Ler um capítulo já liberado
                  </button>
                </div>
              ) : (
                Array.from({ length: Math.min(active.pages, 8) }).map((_, i) => (
                  <PageCanvas
                    key={i}
                    index={i + 1}
                    total={active.pages}
                    hue={hues[i % hues.length]}
                  />
                ))
              )}

              {!locked && (
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => {
                      const idx = manga.chapters.findIndex((c) => c.id === active.id);
                      const prev = manga.chapters[idx + 1];
                      if (prev) setActive(prev);
                    }}
                    className="rounded-lg border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300 transition hover:bg-white/10"
                  >
                    ← Cap. anterior
                  </button>
                  <button
                    onClick={() => {
                      const idx = manga.chapters.findIndex((c) => c.id === active.id);
                      const nxt = manga.chapters[idx - 1];
                      if (nxt && !isLocked(nxt, isPremium)) setActive(nxt);
                      else if (nxt) onWantPremium();
                    }}
                    className="rounded-lg bg-violet-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-violet-500"
                  >
                    Próximo cap. →
                  </button>
                </div>
              )}
            </div>

            {/* side ad — static, omitted entirely for assinantes */}
            {!isPremium && (
              <div className="hidden w-[300px] shrink-0 lg:block">
                <div className="sticky top-4 space-y-4">
                  <AdSlot label="Publicidade" />
                  <AdSlot label="Publicidade" />
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
