import type { ContentType } from "../data/mangas";

const STYLES: Record<ContentType, { bg: string; flag?: string }> = {
  Manga: { bg: "bg-black/55" },
  Manhwa: { bg: "bg-blue-900/70", flag: "🇰🇷" },
  Manhua: { bg: "bg-red-900/70", flag: "🇨🇳" },
  Novel: { bg: "bg-purple-900/70" },
  BR: { bg: "bg-green-700/80", flag: "🇧🇷" },
};

export function getTypeBadge(type: ContentType) {
  return STYLES[type] ?? STYLES.Manga;
}
