import { EARLY_ACCESS_HOURS, type Chapter } from "../data/mangas";

// Milliseconds remaining until a chapter is freely available (early-access window).
export function msUntilFree(ch: Chapter) {
  const released = new Date(ch.releasedAt).getTime();
  const freeAt = released + EARLY_ACCESS_HOURS * 3_600_000;
  return Math.max(0, freeAt - Date.now());
}

export function isEarlyAccess(ch: Chapter) {
  return msUntilFree(ch) > 0;
}

// Returns true if a free user must wait (i.e. locked).
export function isLocked(ch: Chapter, isPremium: boolean) {
  return !isPremium && isEarlyAccess(ch);
}

// Format a duration in ms as "2d 04h", "04h 12m" or "12m 30s".
export function formatCountdown(ms: number) {
  const totalSec = Math.floor(ms / 1000);
  const d = Math.floor(totalSec / 86400);
  const h = Math.floor((totalSec % 86400) / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (d > 0) return `${d}d ${String(h).padStart(2, "0")}h`;
  if (h > 0) return `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m`;
  return `${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
}
