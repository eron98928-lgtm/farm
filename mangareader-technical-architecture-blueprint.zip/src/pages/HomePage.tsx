import Hero from "../components/Hero";
import ContentRow from "../components/ContentRow";
import type { Manga } from "../data/mangas";

type Props = {
  rows: {
    continueReading: Manga[];
    latest: Manga[];
    popular: Manga[];
    topRated: Manga[];
  };
  isPremium: boolean;
  onOpen: (m: Manga) => void;
};

export default function HomePage({ rows, isPremium, onOpen }: Props) {
  return (
    <main>
      <Hero onRead={onOpen} />

      <ContentRow
        title="Continuar lendo"
        subtitle="De onde você parou"
        mangas={rows.continueReading}
        isPremium={isPremium}
        onOpen={onOpen}
        showProgress
      />

      <ContentRow
        title=" Últimos lançamentos"
        subtitle="Capítulos recém-publicados"
        mangas={rows.latest.slice(0, 10)}
        isPremium={isPremium}
        onOpen={onOpen}
      />

      <ContentRow
        title="🔥 Em alta"
        subtitle="Os mais lidos da semana"
        mangas={rows.popular}
        isPremium={isPremium}
        onOpen={onOpen}
      />

      <ContentRow
        title="⭐ Melhor avaliados"
        subtitle="Aclamados pela comunidade"
        mangas={rows.topRated}
        isPremium={isPremium}
        onOpen={onOpen}
      />
    </main>
  );
}
