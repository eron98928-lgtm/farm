import Catalog from "../components/Catalog";
import type { Manga } from "../data/mangas";

type Props = {
  isPremium: boolean;
  onOpen: (m: Manga) => void;
};

export default function CatalogPage({ isPremium, onOpen }: Props) {
  return (
    <main className="min-h-screen bg-[#07070b]">
      <div className="border-b border-white/5 bg-violet-600/5">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
          <h1 className="text-2xl font-bold text-white sm:text-3xl">Catálogo</h1>
          <p className="mt-1 text-sm text-slate-400">
            Explore por tipo, gênero e status. Novos títulos toda semana.
          </p>
        </div>
      </div>
      <Catalog isPremium={isPremium} onOpen={onOpen} />
    </main>
  );
}
