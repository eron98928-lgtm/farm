import { useState } from "react";
import { type Manga, type Chapter } from "../../data/mangas";

type Props = {
  manga: Manga;
  onBack: () => void;
};

export default function AdminChapters({ manga, onBack }: Props) {
  const [chapters, setChapters] = useState<Chapter[]>(manga.chapters);
  const [showForm, setShowForm] = useState(false);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [newChapterNum, setNewChapterNum] = useState(
    chapters.length > 0 ? Math.max(...chapters.map((c) => c.number)) + 1 : 1
  );

  function handleAddChapter() {
    const newChapter: Chapter = {
      id: `ch-${Date.now()}`,
      number: newChapterNum,
      title: `Capítulo ${newChapterNum}`,
      pages: 20,
      releasedAt: new Date().toISOString(),
    };
    setChapters((prev) => [newChapter, ...prev].sort((a, b) => b.number - a.number));
    setNewChapterNum((n) => n + 1);
  }

  function handleDeleteChapter(id: string) {
    if (confirm("Tem certeza que deseja excluir este capítulo?")) {
      setChapters((prev) => prev.filter((c) => c.id !== id));
    }
  }

  function handleEditChapter(chapter: Chapter) {
    setEditingChapter(chapter);
    setShowForm(true);
  }

  function handleSaveChapter(updated: Chapter) {
    setChapters((prev) =>
      prev.map((c) => (c.id === updated.id ? updated : c)).sort((a, b) => b.number - a.number)
    );
    setShowForm(false);
    setEditingChapter(null);
  }

  return (
    <div className="min-h-screen bg-[#07070b] text-white">
      <header className="border-b border-white/10 bg-[#0a0a12]">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-slate-300 transition hover:bg-white/10"
            >
              ← Voltar
            </button>
            <div>
              <div className="text-sm font-bold text-white">{manga.title}</div>
              <div className="text-xs text-slate-500">{chapters.length} capítulos</div>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
        {/* Add Chapter */}
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Capítulos</h2>
          <button
            onClick={handleAddChapter}
            className="rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90"
          >
            + Adicionar Capítulo
          </button>
        </div>

        {/* Chapter List */}
        <div className="space-y-2">
          {chapters.map((ch) => (
            <div
              key={ch.id}
              className="flex items-center justify-between rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 hover:bg-white/[0.04]"
            >
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-violet-600/20 text-sm font-bold text-violet-300">
                  {ch.number}
                </div>
                <div>
                  <div className="font-medium text-white">{ch.title}</div>
                  <div className="text-xs text-slate-500">
                    {ch.pages} páginas · {new Date(ch.releasedAt).toLocaleDateString("pt-BR")}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleEditChapter(ch)}
                  className="rounded bg-blue-600/20 px-3 py-1.5 text-xs font-medium text-blue-300 transition hover:bg-blue-600/30"
                >
                  Editar
                </button>
                <button
                  onClick={() => handleDeleteChapter(ch.id)}
                  className="rounded bg-red-600/20 px-3 py-1.5 text-xs font-medium text-red-300 transition hover:bg-red-600/30"
                >
                  Excluir
                </button>
              </div>
            </div>
          ))}
          {chapters.length === 0 && (
            <p className="py-8 text-center text-sm text-slate-500">
              Nenhum capítulo. Clique em "Adicionar Capítulo" para começar.
            </p>
          )}
        </div>
      </main>

      {/* Edit Modal */}
      {showForm && editingChapter && (
        <ChapterForm
          chapter={editingChapter}
          onSave={handleSaveChapter}
          onCancel={() => {
            setShowForm(false);
            setEditingChapter(null);
          }}
        />
      )}
    </div>
  );
}

function ChapterForm({
  chapter,
  onSave,
  onCancel,
}: {
  chapter: Chapter;
  onSave: (c: Chapter) => void;
  onCancel: () => void;
}) {
  const [data, setData] = useState({
    number: chapter.number,
    title: chapter.title,
    pages: chapter.pages,
    releasedAt: chapter.releasedAt.split("T")[0],
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave({
      ...chapter,
      number: data.number,
      title: data.title,
      pages: data.pages,
      releasedAt: new Date(data.releasedAt).toISOString(),
    });
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#0d0d16] p-6">
        <h3 className="mb-4 text-lg font-semibold text-white">Editar Capítulo</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">Número</label>
            <input
              type="number"
              value={data.number}
              onChange={(e) => setData((p) => ({ ...p, number: parseInt(e.target.value) || 0 }))}
              className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">Título</label>
            <input
              value={data.title}
              onChange={(e) => setData((p) => ({ ...p, title: e.target.value }))}
              className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">Páginas</label>
            <input
              type="number"
              value={data.pages}
              onChange={(e) => setData((p) => ({ ...p, pages: parseInt(e.target.value) || 0 }))}
              className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">Data de Lançamento</label>
            <input
              type="date"
              value={data.releasedAt}
              onChange={(e) => setData((p) => ({ ...p, releasedAt: e.target.value }))}
              className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              className="flex-1 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90"
            >
              Salvar
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 rounded-lg border border-white/10 bg-white/5 px-4 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-white/10"
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
