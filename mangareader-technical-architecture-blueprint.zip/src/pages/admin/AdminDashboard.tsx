import { useState } from "react";
import { MANGAS, type Manga } from "../../data/mangas";
import AdminMangaForm from "./AdminMangaForm";
import AdminChapters from "./AdminChapters";

type View = "list" | "create" | "edit" | "chapters";

export default function AdminDashboard() {
  const [view, setView] = useState<View>("list");
  const [selectedManga, setSelectedManga] = useState<Manga | null>(null);
  const [mangas, setMangas] = useState<Manga[]>(MANGAS);
  const [search, setSearch] = useState("");
  const [adminEmail] = useState(() => localStorage.getItem("admin_email") || "");

  function handleCreate() {
    setView("create");
  }

  function handleEdit(manga: Manga) {
    setSelectedManga(manga);
    setView("edit");
  }

  function handleChapters(manga: Manga) {
    setSelectedManga(manga);
    setView("chapters");
  }

  function handleDelete(id: string) {
    if (confirm(`Tem certeza que deseja excluir este mangá?`)) {
      setMangas((prev) => prev.filter((m) => m.id !== id));
    }
  }

  function handleSave(newManga: Manga, isEdit: boolean) {
    if (isEdit) {
      setMangas((prev) => prev.map((m) => (m.id === newManga.id ? newManga : m)));
    } else {
      setMangas((prev) => [newManga, ...prev]);
    }
    setView("list");
    setSelectedManga(null);
  }

  function handleBack() {
    setView("list");
    setSelectedManga(null);
  }

  const filtered = mangas.filter(
    (m) =>
      m.title.toLowerCase().includes(search.toLowerCase()) ||
      m.author.toLowerCase().includes(search.toLowerCase()),
  );

  if (view === "create") {
    return <AdminMangaForm onSave={(m) => handleSave(m, false)} onCancel={handleBack} />;
  }

  if (view === "edit" && selectedManga) {
    return <AdminMangaForm manga={selectedManga} onSave={(m) => handleSave(m, true)} onCancel={handleBack} />;
  }

  if (view === "chapters" && selectedManga) {
    return <AdminChapters manga={selectedManga} onBack={handleBack} />;
  }

  return (
    <div className="min-h-screen bg-[#07070b] text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-[#0a0a12]">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-600 to-teal-600 text-lg">
              ⚙️
            </div>
            <div>
              <div className="text-sm font-bold text-white">Admin Panel</div>
              <div className="text-[10px] text-slate-500">Gestão de Conteúdo</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {adminEmail && (
              <span className="hidden text-xs text-slate-500 sm:block">{adminEmail}</span>
            )}
            <button
              onClick={() => {
                localStorage.removeItem("admin_auth");
                localStorage.removeItem("admin_email");
                window.location.reload();
              }}
              className="text-xs text-slate-400 hover:text-white"
            >
              Sair
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Mangás</h1>
            <p className="text-sm text-slate-400">Gerencie o catálogo de obras</p>
          </div>
          <button
            onClick={handleCreate}
            className="rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90"
          >
            + Novo Mangá
          </button>
        </div>

        {/* Search */}
        <div className="mb-6">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por título ou autor..."
            className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 sm:max-w-md"
          />
        </div>

        {/* Table */}
        <div className="overflow-hidden rounded-xl border border-white/10 bg-white/[0.02]">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/10 bg-white/[0.03]">
              <tr>
                <th className="px-4 py-3 font-semibold text-slate-300">Título</th>
                <th className="px-4 py-3 font-semibold text-slate-300">Tipo</th>
                <th className="px-4 py-3 font-semibold text-slate-300">Status</th>
                <th className="px-4 py-3 font-semibold text-slate-300">Capítulos</th>
                <th className="px-4 py-3 font-semibold text-slate-300">Nota</th>
                <th className="px-4 py-3 font-semibold text-slate-300 text-right">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m) => (
                <tr key={m.id} className="border-b border-white/5 last:border-0 hover:bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <div className="font-medium text-white">{m.title}</div>
                    <div className="text-xs text-slate-500">{m.author}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="rounded bg-white/5 px-2 py-1 text-xs text-slate-300">{m.type}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded px-2 py-1 text-xs ${
                        m.status === "Ativo"
                          ? "bg-emerald-500/10 text-emerald-300"
                          : m.status === "Hiato"
                          ? "bg-amber-500/10 text-amber-300"
                          : "bg-sky-500/10 text-sky-300"
                      }`}
                    >
                      {m.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{m.chapters.length}</td>
                  <td className="px-4 py-3">
                    <span className="text-amber-400">★ {m.rating}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleChapters(m)}
                        className="rounded bg-violet-600/20 px-3 py-1.5 text-xs font-medium text-violet-300 transition hover:bg-violet-600/30"
                      >
                        Capítulos
                      </button>
                      <button
                        onClick={() => handleEdit(m)}
                        className="rounded bg-blue-600/20 px-3 py-1.5 text-xs font-medium text-blue-300 transition hover:bg-blue-600/30"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => handleDelete(m.id)}
                        className="rounded bg-red-600/20 px-3 py-1.5 text-xs font-medium text-red-300 transition hover:bg-red-600/30"
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <p className="py-8 text-center text-sm text-slate-500">Nenhum mangá encontrado.</p>
          )}
        </div>
      </main>
    </div>
  );
}
