import { useState } from "react";

type Props = {
  onAuth: () => void;
};

export default function AdminLogin({ onAuth }: Props) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Credenciais admin
    const ADMIN_EMAIL = "eron98928@gmail.com";
    const ADMIN_PASSWORD = "12062024";

    setTimeout(() => {
      if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
        localStorage.setItem("admin_auth", "true");
        localStorage.setItem("admin_email", ADMIN_EMAIL);
        onAuth();
      } else {
        setError("Email ou senha incorretos");
      }
      setLoading(false);
    }, 500);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#07070b] px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 text-2xl shadow-lg shadow-emerald-900/40">
            ⚙️
          </div>
          <h1 className="mt-4 text-xl font-bold text-white">Admin Panel</h1>
          <p className="text-[11px] font-medium uppercase tracking-widest text-emerald-400/80">
            MangaReader · Gestão de Conteúdo
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur"
        >
          <div className="mb-4 flex items-center justify-between">
            <span className="text-xs text-slate-500">Credenciais de teste:</span>
            <button
              type="button"
              onClick={() => {
                setEmail("eron98928@gmail.com");
                setPassword("12062024");
              }}
              className="text-xs text-emerald-400 hover:text-emerald-300"
            >
              Preencher automaticamente →
            </button>
          </div>
          <div className="space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-slate-400">E-mail</span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="eron98928@gmail.com"
                className="w-full rounded-lg border border-white/10 bg-black/40 px-4 py-2.5 text-sm text-white outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-slate-400">Senha</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="12062024"
                className="w-full rounded-lg border border-white/10 bg-black/40 px-4 py-2.5 text-sm text-white outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
              />
            </label>

            {error && (
              <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-3 text-sm font-semibold text-white transition enabled:hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {loading ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
              ) : (
                "Entrar"
              )}
            </button>

            <p className="text-center text-[11px] text-slate-600">
              Acesso restrito · Apenas pessoal autorizado
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
