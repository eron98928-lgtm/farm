import { useState } from "react";
import { type Manga, type ContentType, type Status, ALL_GENRES } from "../../data/mangas";

type Props = {
  manga?: Manga;
  onSave: (manga: Manga) => void;
  onCancel: () => void;
};

const TYPES: ContentType[] = ["Manga", "Manhwa", "Manhua", "Novel", "BR"];
const STATUSES: Status[] = ["Ativo", "Hiato", "Completo"];

export default function AdminMangaForm({ manga, onSave, onCancel }: Props) {
  const [formData, setFormData] = useState<Partial<Manga>>({
    id: manga?.id || `manga-${Date.now()}`,
    title: manga?.title || "",
    type: manga?.type || "Manga",
    author: manga?.author || "",
    scanlation: manga?.scanlation || "",
    status: manga?.status || "Ativo",
    genres: manga?.genres || [],
    rating: manga?.rating || 4.5,
    views: manga?.views || 0,
    cover: manga?.cover || "from-violet-600 via-fuchsia-600 to-pink-600",
    accent: manga?.accent || "text-violet-300",
    synopsis: manga?.synopsis || "",
    mature: manga?.mature || false,
    chapters: manga?.chapters || [],
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  function validate() {
    const errs: Record<string, string> = {};
    if (!formData.title?.trim()) errs.title = "Título é obrigatório";
    if (!formData.author?.trim()) errs.author = "Autor é obrigatório";
    if (!formData.synopsis?.trim()) errs.synopsis = "Sinopse é obrigatória";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    onSave(formData as Manga);
  }

  function toggleGenre(genre: string) {
    setFormData((prev) => ({
      ...prev,
      genres: prev.genres?.includes(genre)
        ? prev.genres.filter((g) => g !== genre)
        : [...(prev.genres || []), genre],
    }));
  }

  const coverOptions = [
    "from-indigo-600 via-violet-600 to-fuchsia-700",
    "from-cyan-500 via-blue-600 to-indigo-700",
    "from-rose-400 via-pink-500 to-rose-600",
    "from-slate-700 via-emerald-800 to-slate-900",
    "from-pink-300 via-rose-400 to-red-500",
    "from-amber-400 via-orange-500 to-rose-600",
    "from-emerald-500 via-teal-600 to-cyan-700",
    "from-red-500 via-rose-600 to-purple-700",
    "from-violet-500 via-purple-700 to-slate-900",
    "from-yellow-500 via-orange-600 to-red-700",
    "from-green-500 via-emerald-600 to-yellow-700",
    "from-sky-300 via-blue-400 to-indigo-500",
  ];

  return (
    <div className="min-h-screen bg-[#07070b] text-white">
      <header className="border-b border-white/10 bg-[#0a0a12]">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-slate-300 transition hover:bg-white/10"
            >
              ← Voltar
            </button>
            <div>
              <div className="text-sm font-bold text-white">
                {manga ? "Editar Mangá" : "Novo Mangá"}
              </div>
            </div>
          </div>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
        <div className="space-y-6">
          {/* Título e Autor */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">
                Título <span className="text-red-400">*</span>
              </label>
              <input
                value={formData.title}
                onChange={(e) => setFormData((p) => ({ ...p, title: e.target.value }))}
                className={`w-full rounded-lg border ${errors.title ? "border-red-500" : "border-white/10"} bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20`}
              />
              {errors.title && <p className="mt-1 text-xs text-red-400">{errors.title}</p>}
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">
                Autor <span className="text-red-400">*</span>
              </label>
              <input
                value={formData.author}
                onChange={(e) => setFormData((p) => ({ ...p, author: e.target.value }))}
                className={`w-full rounded-lg border ${errors.author ? "border-red-500" : "border-white/10"} bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20`}
              />
              {errors.author && <p className="mt-1 text-xs text-red-400">{errors.author}</p>}
            </div>
          </div>

          {/* Tipo e Status */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">Tipo</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData((p) => ({ ...p, type: e.target.value as ContentType }))}
                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
              >
                {TYPES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData((p) => ({ ...p, status: e.target.value as Status }))}
                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Scanlation e Nota */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">Scanlation</label>
              <input
                value={formData.scanlation}
                onChange={(e) => setFormData((p) => ({ ...p, scanlation: e.target.value }))}
                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-300">Nota (0-5)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="5"
                value={formData.rating}
                onChange={(e) => setFormData((p) => ({ ...p, rating: parseFloat(e.target.value) || 0 }))}
                className="w-full rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Gêneros */}
          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">Gêneros</label>
            <div className="flex flex-wrap gap-2">
              {ALL_GENRES.map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => toggleGenre(g)}
                  className={`rounded-full px-4 py-1.5 text-xs font-medium transition ${
                    formData.genres?.includes(g)
                      ? "bg-emerald-600 text-white"
                      : "border border-white/10 bg-white/5 text-slate-400 hover:text-white"
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Capa */}
          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">Capa (gradiente)</label>
            <div className="flex flex-wrap gap-2">
              {coverOptions.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setFormData((p) => ({ ...p, cover: c }))}
                  className={`h-10 w-16 overflow-hidden rounded-lg bg-gradient-to-br ring-2 transition ${
                    formData.cover === c ? "ring-emerald-500" : "ring-transparent hover:ring-white/50"
                  } ${c}`}
                />
              ))}
            </div>
          </div>

          {/* Sinopse */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-300">
              Sinopse <span className="text-red-400">*</span>
            </label>
            <textarea
              value={formData.synopsis}
              onChange={(e) => setFormData((p) => ({ ...p, synopsis: e.target.value }))}
              rows={4}
              className={`w-full rounded-lg border ${errors.synopsis ? "border-red-500" : "border-white/10"} bg-white/[0.03] px-4 py-2.5 text-sm text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20`}
            />
            {errors.synopsis && <p className="mt-1 text-xs text-red-400">{errors.synopsis}</p>}
          </div>

          {/* 18+ */}
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={formData.mature}
              onChange={(e) => setFormData((p) => ({ ...p, mature: e.target.checked }))}
              className="h-4 w-4 rounded border-white/20 bg-white/5 text-emerald-600 focus:ring-emerald-500"
            />
            <span className="text-sm text-slate-300">Conteúdo 18+</span>
          </label>

          {/* Ações */}
          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              className="rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-3 text-sm font-semibold text-white transition hover:opacity-90"
            >
              {manga ? "Salvar Alterações" : "Criar Mangá"}
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="rounded-lg border border-white/10 bg-white/5 px-6 py-3 text-sm font-semibold text-slate-300 transition hover:bg-white/10"
            >
              Cancelar
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
