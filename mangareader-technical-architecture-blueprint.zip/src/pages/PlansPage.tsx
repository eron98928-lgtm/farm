import Plans from "../components/Plans";
import type { Plan } from "../data/plans";

type Props = {
  isPremium: boolean;
  daysLeft: number;
  onChoose: (plan: Plan) => void;
};

export default function PlansPage({ isPremium, daysLeft, onChoose }: Props) {
  return (
    <main className="min-h-screen bg-[#07070b]">
      <div className="border-b border-white/5 bg-violet-600/5">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
          <h1 className="text-2xl font-bold text-white sm:text-3xl">Planos</h1>
          <p className="mt-1 text-sm text-slate-400">
            Capítulos novos na hora, sem anúncios e sem espera.
          </p>
        </div>
      </div>
      <Plans isPremium={isPremium} daysLeft={daysLeft} onChoose={onChoose} />
    </main>
  );
}
