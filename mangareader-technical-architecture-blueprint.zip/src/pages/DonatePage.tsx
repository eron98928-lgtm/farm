import Donate from "../components/Donate";

type Props = {
  onDonate: (brl: number) => void;
};

export default function DonatePage({ onDonate }: Props) {
  return (
    <main className="min-h-screen bg-[#07070b]">
      <div className="border-b border-white/5 bg-violet-600/5">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
          <h1 className="text-2xl font-bold text-white sm:text-3xl">Apoiar</h1>
          <p className="mt-1 text-sm text-slate-400">
            Ajude a manter o catálogo crescendo e os tradutores trabalhando.
          </p>
        </div>
      </div>
      <Donate onDonate={onDonate} />
    </main>
  );
}
