import { MANGAS, type Manga } from "../data/mangas";

type Props = {
  onOpen: (m: Manga) => void;
};

export default function LatestPage({ onOpen }: Props) {
  const latest = [...MANGAS].sort(
    (a, b) =>
      new Date(b.chapters[0].releasedAt).getTime() -
      new Date(a.chapters[0].releasedAt).getTime(),
  );

  return (
    <main className="min-h-screen bg-[#07070b]">
      <div className="border-b border-white/5 bg-violet-600/5">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
          <h1 className="text-2xl font-bold text-white sm:text-3xl">Lançamentos</h1>
          <p className="mt-1 text-sm text-slate-400">
            Capítulos recém-publicados · Assinantes leem na hora
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {latest.map((m) => {
            const ch = m.chapters[0];
            const days = Math.floor(
              (Date.now() - new Date(ch.releasedAt).getTime()) / 86400000,
            );
            return (
              <button
                key={m.id}
                onClick={() => onOpen(m)}
                className="group flex gap-4 rounded-xl border border-white/10 bg-white/[0.02] p-4 text-left transition hover:border-violet-500/40 hover:bg-white/[0.04]"
              >
                <div
                  className={`aspect-[3/4] w-20 shrink-0 overflow-hidden rounded-lg bg-gradient-to-br ${m.cover} ring-1 ring-white/10`}
                >
                  <div className="flex h-full items-center justify-center">
                    <span className="text-2xl opacity-25">漫</span>
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="truncate text-sm font-semibold text-white group-hover:text-violet-300">
                    {m.title}
                  </h3>
                  <p className="mt-1 text-xs text-slate-500">{ch.title}</p>
                  <p className="mt-2 text-[11px] text-slate-600">
                    {days === 0 ? "Hoje" : days === 1 ? "Ontem" : `Há ${days} dias`}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </main>
  );
}
