export type Plan = {
  id: "monthly" | "quarterly" | "annual";
  name: string;
  duration: string;
  days: number;
  brl: number;
  highlight?: boolean;
  perks: string[];
};

// Approx XMR price reference (illustrative spot rate, R$/XMR)
export const XMR_BRL_RATE = 920;

export const xmrFromBrl = (brl: number) => (brl / XMR_BRL_RATE).toFixed(4);

export const PLANS: Plan[] = [
  {
    id: "monthly",
    name: "Mensal",
    duration: "30 dias",
    days: 30,
    brl: 10,
    perks: [
      "Acesso imediato a novos capítulos",
      "Remoção completa de anúncios",
      "Histórico de leitura sincronizado",
    ],
  },
  {
    id: "quarterly",
    name: "Trimestral",
    duration: "90 dias",
    days: 90,
    brl: 25,
    highlight: true,
    perks: [
      "Tudo do plano Mensal",
      "Acúmulo de prazo em renovações",
      "Economia de ~17% vs. mensal",
      "Prioridade em novos lançamentos",
    ],
  },
  {
    id: "annual",
    name: "Anual",
    duration: "365 dias",
    days: 365,
    brl: 80,
    perks: [
      "Tudo do plano Trimestral",
      "Maior economia do catálogo",
      "Selo de apoiador no perfil",
      "Suporte prioritário",
    ],
  },
];
