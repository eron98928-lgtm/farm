export type ContentType = "Manga" | "Manhwa" | "Manhua" | "Novel" | "BR";
export type Status = "Ativo" | "Hiato" | "Completo";

export type Chapter = {
  id: string;
  number: number;
  title: string;
  pages: number;
  releasedAt: string; // ISO
};

export type Manga = {
  id: string;
  title: string;
  type: ContentType;
  author: string;
  scanlation: string;
  status: Status;
  genres: string[];
  rating: number;
  views: number;
  cover: string; // gradient classes
  accent: string;
  synopsis: string;
  mature: boolean;
  chapters: Chapter[];
};

// Early-access window in hours (3 days)
export const EARLY_ACCESS_HOURS = 72;

const hoursAgo = (h: number) => {
  const date = new Date();
  date.setHours(date.getHours() - h);
  return date.toISOString();
};

const mkChapters = (count: number, startNum = 1): Chapter[] =>
  Array.from({ length: count }).map((_, i) => {
    const releasedHours = i === 0 ? 8 : i === 1 ? 32 : i === 2 ? 58 : 72 + (i - 3) * 24;
    return {
      id: `ch-${startNum + i}`,
      number: startNum + count - 1 - i,
      title: `Capítulo ${startNum + count - 1 - i}`,
      pages: 14 + ((i * 3) % 20),
      releasedAt: hoursAgo(releasedHours),
    };
  });

export const MANGAS: Manga[] = [
  // ────────────── MANGA (Japonês) ──────────────
  {
    id: "kurogane",
    title: "Kurogane no Tsubasa",
    type: "Manga",
    author: "Reika Mizuhara",
    scanlation: "Estúdio Aurora",
    status: "Ativo",
    genres: ["Ação", "Fantasia", "Sobrenatural", "Shonen"],
    rating: 4.9,
    views: 1_284_000,
    cover: "from-indigo-600 via-violet-600 to-fuchsia-700",
    accent: "text-violet-300",
    mature: false,
    synopsis:
      "Em uma nação onde a memória pode ser forjada como aço, uma jovem ferreira descobre que suas lâminas guardam as lembranças roubadas de um império caído.",
    chapters: mkChapters(48),
  },
  {
    id: "hanabi",
    title: "Hanabi no Kokoro",
    type: "Manga",
    author: "Yuki Sasaki",
    scanlation: "Estúdio Aurora",
    status: "Completo",
    genres: ["Romance", "Drama", "Comédia"],
    rating: 4.8,
    views: 712_300,
    cover: "from-rose-400 via-pink-500 to-rose-600",
    accent: "text-rose-200",
    mature: false,
    synopsis:
      "Dois estranhos se encontram todos os verões sob o mesmo céu de fogos de artifício, sem nunca trocarem seus nomes verdadeiros.",
    chapters: mkChapters(60),
  },
  {
    id: "sakura-blade",
    title: "Sakura Blade Chronicles",
    type: "Manga",
    author: "Mei Tanaka",
    scanlation: "Lótus Traduções",
    status: "Hiato",
    genres: ["Ação", "Romance", "Aventura"],
    rating: 4.5,
    views: 421_700,
    cover: "from-pink-300 via-rose-400 to-red-500",
    accent: "text-pink-200",
    mature: false,
    synopsis:
      "Uma espadachim exilada empunha a única lâmina capaz de cortar o destino — mas cada golpe reescreve uma página de sua própria história.",
    chapters: mkChapters(22),
  },
  {
    id: "silent-mecha",
    title: "Silent Mecha",
    type: "Manga",
    author: "Ren Aoki",
    scanlation: "Estúdio Aurora",
    status: "Hiato",
    genres: ["Ação", "Drama", "Seinen"],
    rating: 4.5,
    views: 333_600,
    cover: "from-slate-500 via-slate-700 to-indigo-900",
    accent: "text-indigo-200",
    mature: false,
    synopsis:
      "A última piloto de um mecha consciente trava uma guerra silenciosa para impedir que a máquina que ama desperte sua arma mais terrível.",
    chapters: mkChapters(19),
  },

  // ────────────── MANHWA (Coreano) ──────────────
  {
    id: "neon-requiem",
    title: "Neon Requiem",
    type: "Manhwa",
    author: "Jae-hyun Kim",
    scanlation: "Lótus Traduções",
    status: "Ativo",
    genres: ["Drama", "Sobrenatural", "Seinen"],
    rating: 4.7,
    views: 932_500,
    cover: "from-cyan-500 via-blue-600 to-indigo-700",
    accent: "text-cyan-300",
    mature: true,
    synopsis:
      "Numa metrópole sob constante vigilância, um andarilho anônimo dança entre o esquecimento e a rebelião contra os senhores do poder.",
    chapters: mkChapters(36),
  },
  {
    id: "crimson-court",
    title: "Crimson Court",
    type: "Manhwa",
    author: "Sora Im",
    scanlation: "Lótus Traduções",
    status: "Ativo",
    genres: ["Romance", "Fantasia", "Drama"],
    rating: 4.8,
    views: 645_100,
    cover: "from-red-500 via-rose-600 to-purple-700",
    accent: "text-rose-200",
    mature: true,
    synopsis:
      "Numa corte onde o sangue real é moeda de troca, uma serva ascende ao trono carregando um segredo capaz de incendiar o império.",
    chapters: mkChapters(33),
  },
  {
    id: "tea-and-thunder",
    title: "Chá & Trovão",
    type: "Manhwa",
    author: "Da-eun Park",
    scanlation: "Lótus Traduções",
    status: "Ativo",
    genres: ["Comédia", "Romance", "Slice of Life"],
    rating: 4.6,
    views: 256_400,
    cover: "from-lime-400 via-emerald-500 to-teal-600",
    accent: "text-lime-200",
    mature: false,
    synopsis:
      "Uma deusa do trovão aposentada abre uma casa de chá entre humanos e descobre que servir clientes é mais difícil que comandar tempestades.",
    chapters: mkChapters(27),
  },

  // ────────────── MANHUA (Chinês) ──────────────
  {
    id: "abyss-walker",
    title: "Abyss Walker",
    type: "Manhua",
    author: "Zhang Wei",
    scanlation: "Vértice Scans",
    status: "Ativo",
    genres: ["Aventura", "Sobrenatural", "Seinen"],
    rating: 4.6,
    views: 588_900,
    cover: "from-slate-700 via-emerald-800 to-slate-900",
    accent: "text-emerald-300",
    mature: true,
    synopsis:
      "Exploradores descem a uma fenda sem fim onde as leis da realidade se desfazem e cada nível cobra um preço da própria identidade.",
    chapters: mkChapters(28),
  },
  {
    id: "iron-monk",
    title: "Punho de Ferro do Monge",
    type: "Manhua",
    author: "Liu Cheng",
    scanlation: "Vértice Scans",
    status: "Completo",
    genres: ["Ação", "Aventura", "Comédia"],
    rating: 4.3,
    views: 297_800,
    cover: "from-orange-400 via-amber-500 to-yellow-600",
    accent: "text-amber-200",
    mature: false,
    synopsis:
      "Um monge desastrado mas inquebrável desce da montanha em busca do melhor chá do mundo — e acaba salvando reinos por acidente.",
    chapters: mkChapters(45),
  },
  {
    id: "jade-emperor",
    title: "Imperador de Jade",
    type: "Manhua",
    author: "Chen Xiaolong",
    scanlation: "Vértice Scans",
    status: "Ativo",
    genres: ["Ação", "Fantasia", "Isekai"],
    rating: 4.5,
    views: 478_300,
    cover: "from-emerald-400 via-green-600 to-teal-800",
    accent: "text-emerald-200",
    mature: false,
    synopsis:
      "Após mil anos selado, um cultivador imortal desperta num mundo onde a energia espiritual quase desapareceu — e precisa reconquistar o trono celestial.",
    chapters: mkChapters(55),
  },

  // ────────────── NOVEL ──────────────
  {
    id: "starborn",
    title: "Starborn Vagrant",
    type: "Novel",
    author: "Leo Antunes",
    scanlation: "Vértice Scans",
    status: "Ativo",
    genres: ["Aventura", "Comédia", "Isekai"],
    rating: 4.4,
    views: 359_400,
    cover: "from-amber-400 via-orange-500 to-rose-600",
    accent: "text-amber-200",
    mature: false,
    synopsis:
      "Um andarilho intergaláctico coleciona dívidas impagáveis e amigos improváveis enquanto foge da corporação mais poderosa da galáxia.",
    chapters: mkChapters(31),
  },
  {
    id: "reborn-tactician",
    title: "O Estrategista Renascido",
    type: "Novel",
    author: "Camila Reis",
    scanlation: "Estúdio Aurora",
    status: "Ativo",
    genres: ["Isekai", "Fantasia", "Drama"],
    rating: 4.7,
    views: 488_200,
    cover: "from-emerald-500 via-teal-600 to-cyan-700",
    accent: "text-teal-200",
    mature: false,
    synopsis:
      "Um general derrotado renasce em um mundo de magia e precisa reconstruir um reino usando apenas a inteligência que o condenou na vida anterior.",
    chapters: mkChapters(40),
  },
  {
    id: "void-academy",
    title: "Academia do Vazio",
    type: "Novel",
    author: "Tobias Marsh",
    scanlation: "Vértice Scans",
    status: "Completo",
    genres: ["Fantasia", "Sobrenatural", "Drama"],
    rating: 4.4,
    views: 214_900,
    cover: "from-violet-500 via-purple-700 to-slate-900",
    accent: "text-violet-200",
    mature: false,
    synopsis:
      "Numa academia onde os alunos estudam o nada absoluto, um garoto sem talento é o único capaz de ouvir o que o Vazio sussurra.",
    chapters: mkChapters(52),
  },

  // ────────────── BR (Brasileira) ──────────────
  {
    id: "sertao-de-ferro",
    title: "Sertão de Ferro",
    type: "BR",
    author: "Danilo Rocha",
    scanlation: "Cangaço Comics",
    status: "Ativo",
    genres: ["Ação", "Aventura", "Drama"],
    rating: 4.8,
    views: 523_600,
    cover: "from-yellow-500 via-orange-600 to-red-700",
    accent: "text-yellow-200",
    mature: true,
    synopsis:
      "No sertão de 1930, um cangaceiro misterioso carrega uma espingarda que nunca precisa ser recarregada e uma dívida de sangue com o próprio diabo.",
    chapters: mkChapters(34),
  },
  {
    id: "folclore-urbano",
    title: "Folclore Urbano",
    type: "BR",
    author: "Raíssa Mendes",
    scanlation: "Cangaço Comics",
    status: "Ativo",
    genres: ["Sobrenatural", "Drama", "Aventura"],
    rating: 4.7,
    views: 412_100,
    cover: "from-green-500 via-emerald-600 to-yellow-700",
    accent: "text-green-200",
    mature: false,
    synopsis:
      "Um grupo de adolescentes de São Paulo descobre que o Saci, a Iara e o Curupira existem — e estão furiosos com o que fizeram com suas matas.",
    chapters: mkChapters(29),
  },
  {
    id: "imperio-das-sombras",
    title: "Império das Sombras",
    type: "BR",
    author: "Thiago Azevedo",
    scanlation: "Cangaço Comics",
    status: "Hiato",
    genres: ["Fantasia", "Ação", "Seinen"],
    rating: 4.6,
    views: 347_500,
    cover: "from-slate-600 via-purple-800 to-slate-950",
    accent: "text-purple-200",
    mature: true,
    synopsis:
      "No submundo do Rio de Janeiro, um ex-policial descobre que as facções criminosas são fachada para uma guerra milenar entre entidades sobrenaturais.",
    chapters: mkChapters(18),
  },
  {
    id: "ceu-de-aluminio",
    title: "Céu de Alumínio",
    type: "BR",
    author: "Luana Farias",
    scanlation: "Cangaço Comics",
    status: "Ativo",
    genres: ["Drama", "Slice of Life", "Romance"],
    rating: 4.9,
    views: 289_700,
    cover: "from-sky-300 via-blue-400 to-indigo-500",
    accent: "text-sky-200",
    mature: false,
    synopsis:
      "Na periferia de Recife, uma garota que sonha em ser mangaká desenha histórias sobre um mundo onde chove estrelas — até que uma estrela cai de verdade no seu quintal.",
    chapters: mkChapters(24),
  },
];

export const ALL_TYPES: ContentType[] = ["Manga", "Manhwa", "Manhua", "Novel", "BR"];
export const ALL_STATUSES: Status[] = ["Ativo", "Hiato", "Completo"];
export const ALL_GENRES = [
  "Ação",
  "Aventura",
  "Comédia",
  "Drama",
  "Fantasia",
  "Isekai",
  "Romance",
  "Seinen",
  "Shonen",
  "Slice of Life",
  "Sobrenatural",
];
